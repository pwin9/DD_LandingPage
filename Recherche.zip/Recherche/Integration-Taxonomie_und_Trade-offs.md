# Thema 3: Integration-Taxonomie und Trade-offs

## TL;DR
- **Sechs Integrationsmuster-Familien dominieren die Praxis** – API-basiert (REST/GraphQL/gRPC/Webhooks), Event-getrieben (Kafka & Co.), ETL/ELT, CDC, Middleware/iPaaS und File-based/EDI. Die überwältigende Mehrheit der Produktionssysteme kombiniert mehrere davon; die richtige Wahl folgt aus Latenz-, Kopplungs- und Konsistenzanforderungen, nicht aus Hype.
- **REST Level 2, Apache Kafka, ELT (Fivetran/Airbyte + dbt + Cloud-Warehouse) und log-basiertes CDC (Debezium) sind die verlässlichsten, breit produktiv validierten Muster (Kategorie A/B)**. File-based/EDI ist trotz "Legacy-Ruf" in Finance/Healthcare/B2B weiterhin unverzichtbar.
- **MCP ist echter Fortschritt, aber (noch) nicht "etabliert" im Sinne jahrelanger Produktionshärtung** – die Adoption ist real und außergewöhnlich schnell (industrieweite Unterstützung, Linux-Foundation-Governance seit Dez. 2025), aber Security- und Governance-Reife hinken deutlich hinterher. Ehrliche Einordnung: **Kategorie B mit signifikanten C-Vorbehalten bei Security**.

## Key Findings

1. **Der grundlegende Trade-off ist immer derselbe**: synchron (Request/Response, enge zeitliche Kopplung, einfaches Debugging) vs. asynchron (Events/Messages, lose Kopplung, Eventual Consistency, schwierigeres Debugging). Fast alle Entscheidungen lassen sich auf diese Achse plus "Batch vs. Echtzeit" reduzieren.
2. **REST bleibt Default für Web-APIs**, aber HATEOAS (Richardson Level 3) ist in der Praxis fast nie umgesetzt – Level 2 ist der De-facto-Standard.
3. **gRPC gewinnt bei interner Service-zu-Service-Kommunikation** (Performance, Streaming, Contract-First), REST bei öffentlichen/Browser-APIs, GraphQL bei heterogenen Client-Datenbedürfnissen.
4. **Kafka ist der De-facto-Standard für Event-Streaming** und Rückgrat vieler EDA-Architekturen; Alternativen wie RabbitMQ (Task-Queues/Routing), NATS (leichtgewichtig/Latenz), Redpanda (Kafka-kompatibel, C++), SQS/SNS und Google Pub/Sub (managed) haben klar abgegrenzte Nischen.
5. **ELT hat ETL im Cloud-Warehouse-Kontext verdrängt**; klassisches ETL bleibt für On-Prem und Compliance (keine Roh-PII im Warehouse) relevant.
6. **CDC (Debezium) ist die Brücke** zwischen operationalen DBs und Event-/Analytics-Welt – die bessere Wahl gegenüber Batch-ETL, wann immer niedrige Latenz, Delete-Propagation und Before/After-State gebraucht werden.
7. **Der klassische monolithische ESB ist zu Recht in Ungnade gefallen** ("Enterprise Hairball"); seine Aufgaben verteilen sich heute auf iPaaS, Microservice-Kommunikation, API-Gateways und Service Meshes.
8. **MCP hat in ~12 Monaten eine Adoption erreicht, für die andere Standards Jahre brauchten** – aber die dokumentierten Sicherheitslücken (Tool Poisoning, Prompt Injection, CVE-2025-6514) sind ernst und die Governance-Standards noch jung.

## Details

### 3.1 Grundlegende Integrationsmuster im Überblick

Integration in heterogenen Systemlandschaften lässt sich entlang zweier orthogonaler Achsen ordnen:

- **Synchron vs. asynchron**: Bei synchroner Integration wartet der Aufrufer auf eine Antwort (Request/Response, z. B. REST-Call, gRPC-Unary). Es besteht *temporale Kopplung* – beide Seiten müssen gleichzeitig verfügbar sein. Vorteil: einfaches mentales Modell, sofortige Konsistenz, leichtes Debugging. Nachteil: Verfügbarkeits- und Latenz-Kaskaden.
- **Request-driven vs. event-driven**: Request-driven ("pull"/Kommando) bedeutet, der Konsument fragt aktiv an bzw. ein Sender adressiert einen bekannten Empfänger. Event-driven ("push"/Fakt) bedeutet, ein Produzent publiziert ein Ereignis, ohne die Konsumenten zu kennen – *lose Kopplung*, aber Eventual Consistency und implizite Kontrollflüsse.

Diese Achsen korrelieren mit **Batch vs. Streaming**: ETL-Batch ist typischerweise request-/schedule-driven und asynchron auf Stunden-Ebene; Event-Streaming ist push-basiert und (nahe) Echtzeit.

Die Enterprise Integration Patterns von Hohpe & Woolf (2003) benennen vier grundlegende Integrationsstile, die bis heute gültig sind: **File Transfer, Shared Database, Remote Procedure Invocation (RPC) und Messaging**. Ihre zentrale These – Messaging habe sich durchgesetzt, weil es als einziger Stil auf Hunderte Produzenten/Konsumenten bei loser Kopplung skaliert – gilt weiterhin, wobei File Transfer und RPC keineswegs verschwunden sind.

### 3.2 API-basierte Integration

**REST (Representational State Transfer)** – Der De-facto-Standard für Web-APIs. Das **Richardson Maturity Model (RMM)**, popularisiert von Martin Fowler, klassifiziert REST-Reife in vier Stufen: Level 0 (einzelner Endpoint, RPC-Stil, z. B. SOAP-über-POST), Level 1 (Ressourcen mit eigenen URIs), Level 2 (korrekte HTTP-Verben + Statuscodes), Level 3 (**HATEOAS** – Hypermedia as the Engine of Application State, selbstbeschreibende Links).
- **Theorie vs. Praxis**: Roy Fielding betrachtet Level 3 als Vorbedingung für "echtes" REST. In der Praxis stabilisieren sich die meisten Produktionssysteme jedoch bei **Level 2**; HATEOAS wird selbst von APIs, die sich "RESTful" nennen, fast durchgängig ignoriert. Gründe: höhere Client-Komplexität, größere Payloads, fehlendes Tooling, geringer Mehrwert für interne Services mit kontrollierten Clients. HATEOAS lohnt sich am ehesten für öffentliche APIs, deren Client-Update-Zyklen man nicht kontrolliert.
- **Kategorie A** (etabliert/praxisbewährt). Stärken: universelle Tool-/Browser-/CDN-Unterstützung, Caching über URLs, flache Lernkurve. Schwächen: Over-/Underfetching, Chattiness bei vielen kleinen Calls.

**GraphQL** – 2012 bei Facebook/Meta intern entwickelt, 2015 öffentlich, seit 2018 unter neutraler Governance (GraphQL Foundation/Linux Foundation). Eine Query-Sprache, bei der der Client exakt die benötigten Felder in einer einzigen Anfrage spezifiziert.
- **Kernproblem, das es adressiert**: **Overfetching** (Client erhält mehr Daten als nötig) und **Underfetching** (mehrere Requests nötig, N+1-Problem). Ein einziger Endpoint liefert genau die angefragte Datenstruktur.
- **Trade-offs vs. REST**: Vorteile bei heterogenen/mobilen Clients mit diversen Datenbedürfnissen und komplexen Datenbeziehungen. Nachteile: Caching deutlich schwieriger (kein URL-basiertes HTTP-Caching), serverseitige Query-Komplexität, N+1-Resolver-Problem (Mitigation via DataLoader-Pattern), Notwendigkeit von Query-Depth-Limiting/Cost-Analysis gegen Missbrauch. Wichtig: GraphQL *löst* Over-/Underfetching nicht automatisch – schlecht designte Resolver reproduzieren beide Probleme. REST kann mit Sparse Fieldsets (`?fields=...`) Ähnliches erreichen, nur weniger standardisiert.
- **Kategorie B** (aktueller Standard mit guter Adoption). Implementierungen: Apollo Server/Client, Relay, AWS AppSync, WunderGraph.

**gRPC / RPC** – 2015 von Google open-source veröffentlicht. Baut auf **HTTP/2** und **Protocol Buffers** (binäres, schemabasiertes Serialisierungsformat, v3 seit 2016). Contract-First: Eine `.proto`-Datei definiert Services und Messages, aus der Client-/Server-Code in vielen Sprachen (Go, Java, Python, C++, Rust, …) generiert wird.
- **Performance-Charakteristik**: kompakte Binärnachrichten + Multiplexing über eine TCP-Verbindung. Tech-Insider (April 2026) beziffert "up to 77% lower latency on small payloads (2.3 ms vs 10.1 ms p50)" und eine "10x reduction in serialized message size" – jeweils gegen HTTP/1.1+JSON als Baseline. Wichtige Ehrlichkeit: Der Vorsprung schrumpft deutlich, wenn REST über HTTP/2 plus Binärformate (MessagePack/CBOR) läuft – dann oft nur noch 10–25 %. Ein unabhängiger Serialisierungs-Benchmark fand für Protobuf gegenüber best-case komprimiertem JSON nur ~67 % Median-Größenreduktion (Imaginary Cloud). Die "77 %"-/"10×"-Zahlen illustrieren also Größenordnungen bei ungünstiger Baseline, keine Garantien.
- **Wann sinnvoll**: interne Service-zu-Service-Kommunikation mit hohem Volumen, Streaming (server-/client-/bidirektional), polyglotte Umgebungen mit striktem Contract. **Nicht** ideal für Browser (benötigt gRPC-Web-Proxy) und öffentliche APIs (Lernkurve, kein einfaches curl/Postman).
- **Kategorie A** in der internen Microservice-Kommunikation.

**Webhooks** – Leichtgewichtiges Event-Pattern: statt Polling ruft der Server den Client via HTTP POST an, sobald ein Ereignis eintritt. Von Jeff Lindsay 2007 geprägt. Komplementär zu APIs ("Du rufst eine API auf, wenn du etwas brauchst; ein Webhook ruft dich an, wenn etwas passiert").
- Praktisch überall bei SaaS-Integrationen (GitHub, Stripe, Slack). Stärken: einfach, echtzeitnah, ressourcenschonend gegenüber Polling. Schwächen: Empfänger muss ständig verfügbar sein, verpasste Events bei Downtime erfordern Retry-Logik, Zustellgarantien/Debugging schwierig, Signatur-Verifikation nötig. Für 1:1-Punkt-zu-Punkt gut; bei mehreren Konsumenten ist Pub/Sub überlegen. **Kategorie A**.

**API-Gateways** – Zentraler Eintrittspunkt vor APIs; übernehmen Authentifizierung, Rate-Limiting, Routing, TLS-Terminierung, Observability. Beispiele: Kong, Apache APISIX, Tyk, AWS API Gateway. In Microservice-Landschaften entlasten sie einzelne Services von Querschnittsthemen. Sie können auch Async-/Webhook-Muster nachrüsten (z. B. Kong Event Hooks). **Kategorie A**.

**Praktische Trade-offs (API-Familie)**:
- *Kopplung*: REST/GraphQL lose (HTTP-Standard), gRPC enger (geteilte `.proto`).
- *Versionierung*: REST via URL/Header-Versionierung; gRPC via Protobuf-Feldregeln (nie Feldnummern wiederverwenden, nur additive Änderungen); GraphQL via Feld-Deprecation (schemagetrieben, tendenziell versionslos).
- *Latenz*: gRPC < REST/GraphQL (typisch).
- *Discoverability*: HATEOAS (theoretisch) > OpenAPI/Swagger (praktisch dominierend) > gRPC-Reflection.

### 3.3 Event-getriebene Integration

**Publish-Subscribe & Message Queues vs. Event Streaming** – Grundunterscheidung:
- **Message Queue** (z. B. RabbitMQ, SQS): Nachricht wird typischerweise nach Konsum entfernt; Fokus auf Task-Verteilung, flexibles Routing, Competing Consumers; kein Replay.
- **Event Streaming / Log** (Kafka, Redpanda, Pulsar): Events werden in einem append-only Log persistiert und bleiben lesbar (Replay); mehrere unabhängige Konsumentengruppen (Fan-out); Fokus auf hohen Durchsatz und Wiederholbarkeit.

**Apache Kafka** – 2011 bei LinkedIn entwickelt (Jay Kreps, Neha Narkhede, Jun Rao), open-source; Confluent (2014) als kommerzieller Träger. **Der De-facto-Standard** für Event-Streaming.
- **Architektur/Log-Modell**: Ein **Topic** ist ein in **Partitionen** aufgeteiltes, append-only Log. Jeder Record hat einen eindeutigen, sequentiellen **Offset**. Ein **Broker** hält Partitionen; Replikation sichert Fehlertoleranz. Records mit gleichem **Key** landen (via murmur2-Hash) stets in derselben Partition → **Ordering-Garantie pro Partition**, nicht über Partitionen hinweg.
- **Consumer Groups**: Innerhalb einer Gruppe wird jede Partition genau einem Konsumenten zugewiesen (paralleles Skalieren); mehrere Gruppen lesen dasselbe Topic unabhängig (Fan-out). Mehr Konsumenten als Partitionen → Idle-Konsumenten.
- **Zustellsemantik**: Default **at-least-once** (Duplikate bei Consumer-Restart möglich). **Exactly-once (EOS)** seit 0.11 möglich via idempotenten Producern (`enable.idempotence=true`), transaktionalen APIs (2-Phase-Commit über Partitionen) und `isolation.level=read_committed`. At-most-once via Fire-and-forget.
- **Produktions-Skala (Beleg)**: LinkedIn betrieb laut LinkedIn Engineering Blog (2019, Jon Lee & Wesley Wu, "How LinkedIn customizes Apache Kafka for 7 trillion messages per day") über 100 Kafka-Cluster mit >4.000 Brokern, >100.000 Topics, 7 Mio. Partitionen und **über 7 Billionen (7 trillion) Nachrichten pro Tag** – Zitat: "The total number of messages handled by LinkedIn's Kafka deployments recently surpassed 7 trillion per day." (Stand 2019; heute höher.) Ökosystem: Kafka Connect (Integration), Kafka Streams (Stream-Processing), breite Tool-Landschaft. **Kategorie A**.

**Alternativen im Vergleich**:
- **RabbitMQ** – Klassischer Message-Broker (AMQP), exzellent für komplexes Routing, Task-Queues, Competing Consumers, niedrige Latenz bei moderatem Durchsatz. Schwächer bei sehr hohem Durchsatz und horizontaler Skalierung als Kafka. Kein natives Log/Replay (der Stream-Plugin-Ansatz mit ~50k msg/s Deckel existiert).
- **AWS SQS/SNS** – Vollmanaged; SQS (Queue) + SNS (Pub/Sub-Fan-out). Minimaler Betrieb, gut für einfache Entkopplung in AWS; kein Log/Replay wie Kafka.
- **Redpanda** – Kafka-API-kompatibel, in C++ implementiert, ohne ZooKeeper/JVM. Wirbt laut eigenem Benchmark-Blog (OpenMessaging-Benchmark) mit "10x faster tail latencies than Apache Kafka—with up to 3x fewer nodes"; unabhängige Gegentests (u. a. von Confluent-Technologe Jack Vanlightly) zeigen jedoch Fälle, in denen Kafka überlegen ist – die Zahlen sind also Anbieter-Marketing und kontextabhängig. Ideal für Kafka-Know-how bei reduziertem Ops-Aufwand und Edge/limitierte Compute-Umgebungen; kleineres Ökosystem.
- **Google Pub/Sub** – Vollmanaged, global skalierend, gut für GCP-native Event-Verteilung.
- **NATS (JetStream)** – Extrem leichtgewichtig (Single-Binary ~15 MB), Sub-Millisekunden-p50-Latenz; ideal für Microservice-Messaging/IoT/Edge. Weniger Feature-Reichtum als Kafka.
- **Apache Pulsar** – Trennt Compute (Broker) von Storage (BookKeeper); Stärke bei Multi-Tenancy und Geo-Replikation (gleicher Topic-Name, in Broker-Layer eingebaut). Größere Betriebskomplexität.

**Event-Driven Architecture (EDA): Choreography vs. Orchestration** –
- **Choreography**: Services reagieren dezentral auf Events, kein zentraler Koordinator. Vorteile: minimale Kopplung, keine zusätzliche Infra für einfache, stabile Flows. Nachteil: Der Gesamtzustand einer verteilten Transaktion (**Saga**) ist *implizit* – über Event-Logs mehrerer Services verstreut, schwer zu debuggen wenn eine Saga hängt.
- **Orchestration**: Ein zentraler Orchestrator kommandiert die Schritte. Vorteile: explizite Sichtbarkeit, leichteres Testing. Nachteile: potenzieller Flaschenhals/Single Point, temporale Kopplung.
- Faustregel aus der Praxis: Choreography für hohen Durchsatz/lose gekoppelte Flows, Orchestration für komplexe, stateful, geschäftskritische Workflows. Große Systeme mischen beides. Das **Saga-Pattern** (Garcia-Molina & Salem, 1987) verwaltet verteilte Transaktionen über kompensierende Aktionen.

**Event Sourcing** – Verwandtes, aber unterscheidbares Muster: Statt nur den aktuellen Zustand zu speichern, wird die *vollständige Sequenz von Zustandsänderungen* (Events) als Source of Truth persistiert; der aktuelle Zustand wird durch Replay rekonstruiert. Oft mit **CQRS** kombiniert. Abgrenzung: EDA nutzt Events zur *Kommunikation zwischen* Services; Event Sourcing nutzt Events zur *Persistenz innerhalb* eines Service. Stärken: vollständiger Audit-Trail, Zeitreise. Schwächen: Replay-/Snapshot-Komplexität, Schema-Evolution der Events, steilere Lernkurve. **Kategorie B** (bewährt, aber bewusst dosiert einzusetzen).

**Trade-offs (Event-Familie)**: Eventual Consistency statt sofortiger Konsistenz; Debugging über verteilte Logs (Distributed Tracing wird Pflicht); **Schema Evolution** ist zentral. Die **Confluent Schema Registry** verwaltet Avro-/Protobuf-/JSON-Schemas zentral und erzwingt Kompatibilitätsregeln: **BACKWARD** (neue Consumer lesen alte Daten; Default), **FORWARD** (alte Consumer lesen neue Daten), **FULL** (beides), **NONE**. Best Practice: additive Felder mit Defaults; nie ein Feld ohne Default hinzufügen. Für Reliability zusätzlich: idempotente Consumer, Dead Letter Queues, Outbox-Pattern (atomare DB-Änderung + Event-Publikation).

### 3.4 ETL/ELT

**ETL vs. ELT** – Beim klassischen **ETL** (Extract-Transform-Load) wird auf einem separaten Server transformiert, *bevor* geladen wird. Beim modernen **ELT** wird roh geladen und *danach* im Warehouse transformiert. Der Wechsel wurde durch leistungsfähige, günstige Cloud Data Warehouses/Lakehouses ausgelöst (Bezug Thema 1: Snowflake, BigQuery, Redshift, ClickHouse, Databricks).
- **ELT ist der dominierende Cloud-Standard**: billiger Storage + starke Warehouse-Compute, Rohdaten bleiben erhalten (Transformationen reproduzierbar/reversibel).
- **ETL bleibt relevant** bei On-Prem und Compliance (keine rohe PII im Warehouse speichern). Die meisten realen Plattformen fahren hybrid.

**Batch vs. Micro-Batch vs. Streaming** – Batch (Stunden/Tage, klassisch), Micro-Batch (Minuten, z. B. Spark Structured Streaming), echtes Streaming (Sekunden/Millisekunden, Flink). Wahl folgt der Freshness-Anforderung.

**Etablierte Tools (Modern Data Stack)**:
- **Extraction/Loading**: **Fivetran** (vollmanaged, viele Connectoren, planbarer Betrieb), **Airbyte** (open-source, self-hostbar, flexibel; Lizenz kostenlos, aber Infrastruktur-/Engineering-Kosten).
- **Transformation**: **dbt** – De-facto-Standard für das "T" in ELT; SQL-basierte, versionierte, getestete, dokumentierte Transformationen im Warehouse. Kann *nicht* extrahieren/laden und braucht externen Scheduler.
- **Orchestrierung**: **Apache Airflow** (Python-DAGs, Industriestandard), Alternativen Dagster, Prefect, Kestra.
- **Verarbeitung (Big Data)**: **Apache Spark** (Batch + Micro-Batch), **Apache Flink** (echtes Streaming, stateful, niedrige Latenz).
- Typischer Stack: Fivetran/Airbyte (EL) → dbt (T) → Snowflake/BigQuery, orchestriert von Airflow. **Kategorie A/B**.

**Data Pipeline Reliability Patterns**: **Idempotenz** (mehrfache Ausführung = gleiches Ergebnis; essenziell bei at-least-once), **Retries** mit Backoff, **Dead Letter Queues** (nicht verarbeitbare Records isolieren), **Monitoring/Alerting** (Freshness, Lag, Volumen), **Backfilling**.

### 3.5 CDC im Integrationskontext

**Referenz Thema 1**: Log-basiertes CDC via **Debezium** (Kafka Connect, Outbox-Pattern) wurde bereits als **Kategorie A** etabliert. Debezium liest das Transaktionslog der DB (WAL/binlog) und erfasst Inserts/Updates/Deletes mit Before/After-State im Moment des Commits. Läuft auch ohne Kafka (Debezium Server / Embedded Engine → Pulsar, Kinesis, Pub/Sub).

**Einordnung: CDC vs. Batch-ETL vs. Event-Driven** –
- **CDC vs. Batch-ETL**: Batch pollt nach Zeitplan (Stunden) mit Full-/Incremental-Dumps – vier fundamentale Schwächen: stale Daten, "Thundering Herd" (Lastspitzen), keine zuverlässige Delete-Propagation, kein Before-State. CDC löst alle vier: Sub-Sekunden-Latenz, minimaler Source-Impact, vollständiger Change-Trail. **CDC ist die bessere Wahl**, wenn niedrige Latenz, Delete-Erfassung, Audit/Before-State oder häufige Änderungen gefragt sind.
- **Wann Batch-ETL reicht**: Wenn stündliche/tägliche Freshness genügt, ist Batch **einfacher und billiger** – CDC fügt Komplexität hinzu (Log-Zugriff, Kafka-Infra, Schema-Evolution). SaaS-Quellen (Stripe, Shopify) exponieren ohnehin keine Transaktionslogs → dort API/Batch.
- **CDC als Brücke**: CDC ist konzeptionell die Verbindung zwischen der operationalen (OLTP) und der Event-/Analytics-Welt – es verwandelt DB-Änderungen in einen Event-Stream, der sowohl Analytics-Ziele (Warehouse/Lakehouse) als auch Event-Driven-Microservices speisen kann. Damit ist CDC häufig der pragmatischste Weg, bestehende Systeme *ohne Code-Änderung* event-fähig zu machen. CDC ist technisch ein Spezialfall des "Extract" – nur eben inkrementell und log-basiert.

### 3.6 Middleware und Enterprise Integration Patterns

**Enterprise Service Bus (ESB)** – Begriff 2002 von Gartner-VP Roy Schulte geprägt; Kern der SOA-Ära. Ein zentraler Bus für Routing, Transformation, Protokoll-Vermittlung.
- **Warum in Ungnade gefallen**: Der ESB wurde zum monolithischen, zentralen Flaschenhals – die "**Enterprise Hairball**" (Holly Cummins). Weil die Integrationsschicht monolithisch war, mussten alle Änderungen sorgfältig koordiniert werden, was das gesamte Unternehmen ausbremste. Microservices propagieren stattdessen "**smart endpoints and dumb pipes**" (Martin Fowler) – Orchestrierungslogik gehört in die Services, nicht in eine zentrale Bus-Middleware.
- **Heutige Rolle**: Nicht tot, aber transformiert – vom zentralen Monolithen zu verteilten, containerisierten Integrationsservices (z. B. MuleSoft Anypoint deployt Integrationen als unabhängige Microservices, kein zentraler Bus mehr).

**Enterprise Integration Patterns (Hohpe & Woolf, 2003)** – *Das* Standardwerk ("Enterprise Integration Patterns: Designing, Building, and Deploying Messaging Solutions", Addison-Wesley, erschienen 10. Oktober 2003, ISBN 978-0321200686; über 100.000 verkaufte Exemplare). Ein Katalog von **65 Mustern in 9 Kategorien**, die bis heute die "De-facto-Sprache" für asynchrone verteilte Systeme bilden. Wichtigste Muster:
- **Message Router** – leitet Nachrichten basierend auf Bedingungen weiter; **Content-Based Router** entscheidet anhand des Nachrichteninhalts.
- **Message Filter** – lässt nur relevante Nachrichten durch.
- **Splitter** – zerlegt eine Nachricht in mehrere Teilnachrichten; **Aggregator** – (stateful) kombiniert zusammengehörige Nachrichten wieder zu einer.
- **Scatter-Gather / Composed Message Processor** – verteilt an mehrere Empfänger und reaggregiert Antworten.
- **Publish-Subscribe Channel, Point-to-Point Channel, Dead Letter Channel, Guaranteed Delivery, Idempotent Receiver, Competing Consumers, Correlation Identifier**.
- Diese Muster sind zeitlos und finden sich heute 1:1 in Kafka, RabbitMQ, iPaaS-Flows und Frameworks wie **Apache Camel** (die bekannteste EIP-Implementierung), Spring Integration und Mule wieder.

**iPaaS (Integration Platform as a Service)** – Moderne, cloud-basierte Alternative zur selbstbetriebenen Middleware.
- **MuleSoft (Anypoint Platform)** – 2003 als MuleSource gegründet, am 20. März 2018 von Salesforce für einen Enterprise Value von ca. 6,5 Mrd. USD (44,89 USD/Aktie, 36 % Prämie) übernommen (laut Salesforce-Pressemitteilung: "Salesforce will acquire MuleSoft for an enterprise value of approximately $6.5 billion."); API-led Connectivity, unterstützt SOA und Microservices. Enterprise-Vertrag (keine öffentlichen Preise). Gartner-Leader für iPaaS/API-Management.
- **Zapier/Make** – Low-/No-Code für einfachere Fälle (SaaS-App-Verknüpfung, Business-Automation).
- Weitere: Boomi, Workato, Celigo, Informatica, SnapLogic, Jitterbit, TIBCO. **Kategorie A/B** je nach Reifegrad.

**Microservices-Kommunikationsmuster** – Moderne Alternative zur klassischen Middleware: direkte synchrone Calls (REST/gRPC) für Request/Response + asynchrones Messaging (Kafka/RabbitMQ) für Entkopplung; ergänzt um Saga, Outbox, CQRS, API-Composition (Chris Richardson, microservices.io).

**Service Mesh (Istio, Linkerd)** – Eine dedizierte Infrastrukturschicht für Service-zu-Service-Kommunikation, klassisch via **Sidecar-Proxy** (Envoy) pro Pod.
- **Rolle: Netzwerk-Infrastruktur, nicht Applikationsintegration**. Ein Service Mesh liefert mTLS, Traffic-Management, Retries/Circuit-Breaking, Observability – *transparent*, ohne Applikationscode zu ändern. Es adressiert die *"wie"*-Frage der Netzwerkkommunikation (Sicherheit, Zuverlässigkeit, Telemetrie), **nicht** die *"was"*-Frage der Datentransformation/-routing auf Applikationsebene (das ist EIP/iPaaS-Domäne).
- Wichtige Entwicklung: **Istio Ambient Mesh** (sidecar-less, ztunnel + Waypoint-Proxies) reduziert Ressourcen-Overhead. Für einfache Apps ist ein Mesh oft unnötiger Overhead. **Kategorie B** (etabliert in großen K8s-Landschaften, aber selektiv einzusetzen).

### 3.7 File-based Integration

**Batch File Transfer (SFTP etc.)** – Trotz "Legacy"-Ruf **weiterhin Standard** in Finance, Healthcare und B2B. Gründe für die Persistenz: einfach zu automatisieren, leicht zu erklären/auditieren, extrem zuverlässig, keine ständige Verfügbarkeit beider Seiten nötig, universelle Partner-Kompatibilität.
- **Protokolle**: **SFTP** (SSH-basiert; am verbreitetsten für file-basiertes EDI, easy zu automatisieren), **AS2** (HTTP/S mit signierten Empfangsbestätigungen/MDNs, Non-Repudiation; von IETF definiert, >2 Jahrzehnte Interop-Tests; z. B. Walmart), **AS4**, **OFTP2** (Automotive), **FTPS**, **VAN** (Value-Added Network als managed Intermediär). Oft eingebettet in **MFT** (Managed File Transfer).

**Dateiformate – Trade-offs**:
- **CSV** – Menschlich lesbar, universell; keine Typen, keine Kompression, jede Query liest alle Spalten. Nur für kleine Interchange-Files. Regel: "Nie CSV als Schnittstelle zwischen zwei Systemen, die du beide kontrollierst."
- **JSON** – Selbstbeschreibend, flexibel, ideal für verschachtelte API-/Event-Payloads; groß und langsam zu durchsuchen, nicht für Large-Scale-Storage.
- **XML** – Stark strukturiert, schema-validierbar (XSD), Basis vieler EDI-/SOAP-Standards; verbose, komplexes Parsing; in Data Processing kaum noch genutzt.
- **Avro** – Zeilenbasiertes Binärformat mit JSON-Schema; exzellente **Schema-Evolution**, ideal für Streaming/Kafka und record-weisen Zugriff.
- **Parquet** – Spaltenbasiertes Binärformat; exzellente Kompression + Predicate-Pushdown; **Default für Analytics**. Benchmarks (MotherDuck, NYC-Taxi-Datensatz, 11,2 Mio. Zeilen, DuckDB) zeigen 6–8× kleinere Dateien (164 MB Parquet-Zstd vs. 1,09 GB CSV) und 22–60× schnellere Analytics-Queries vs. CSV (abhängig von Spaltenzahl); `count(*)` aus Row-Group-Metadaten ~160× schneller. Ungeeignet für Row-Level-Updates, Einzelrecord-Streaming, winzige Dateien.
- Faustregel: Roh rein wie die Quelle liefert (JSON/Avro/CSV), für Analytics-Storage auf **Parquet+zstd** konvertieren; Table-Formate (Iceberg, Delta Lake) legen Transaktionen/Zeitreise darüber.

**EDI (Electronic Data Interchange)** – Etablierter Standard für strukturierten B2B-Dokumentenaustausch (Purchase Orders, Invoices, ASNs, Healthcare-Claims, Remittance). Standards: **X12** (Nordamerika), **EDIFACT** (international). Weiterhin dominant in Retail, Healthcare, Finance, Logistik, Manufacturing, Automotive. **Kategorie A** – uralt, aber unverzichtbar.

**Wann File-based die pragmatischste Wahl ist**: geplanter, hochvolumiger Austausch mit externen Partnern, die keine Echtzeit-API bieten/wollen; regulierte Umgebungen mit Audit-/Non-Repudiation-Anforderungen; Legacy-Systeme ohne moderne Konnektoren; Batch-orientierte Geschäftsprozesse (Nightly Reconciliation). File-based ist hier nicht "Schuld", sondern die zuverlässigste und am besten verstandene Lösung.

### 3.8 MCP (Model Context Protocol) – kritische Einordnung

**Ursprung**: Von **Anthropic** im **November 2024** als offener Standard vorgestellt, um KI-Anwendungen (LLMs/Agenten) standardisiert mit externen Systemen (Tools, Daten, Kontext) zu verbinden – "USB-C für KI-Tools".

**Funktionsweise**:
- **Client-Server-Architektur** mit drei Rollen: **Host** (KI-Anwendung, z. B. Claude Desktop, ChatGPT, Cursor), **Client** (Konnektor im Host, eine 1:1-Verbindung pro Server), **Server** (exponiert Fähigkeiten).
- **Protokoll**: **JSON-RPC 2.0** als Datenschicht (Lifecycle, Capability-Negotiation, Notifications). **Transporte**: STDIO (lokal, Subprozess über stdin/stdout) und Streamable HTTP (remote, optional SSE).
- **Server-Primitive**: **Tools** (ausführbare Funktionen, model-controlled – das LLM entscheidet, wann es aufruft), **Resources** (read-only Datenquellen, application-controlled), **Prompts** (wiederverwendbare Templates, user-controlled). Client-Primitive: Sampling, Elicitation, Roots.
- Kernvorteil: Ein Server funktioniert ohne Änderung mit *jedem* kompatiblen Host – das M×N-Integrationsproblem (M Modelle × N Tools) wird zu M+N reduziert.

**Tatsächlicher Adoptionsstand (recherchiert, Stand Ende 2025 / Anfang 2026)**:
- **Industrieweite Unterstützung**: **OpenAI** adoptierte MCP im März 2025 über Agents SDK, Responses API und ChatGPT. Sam Altman via X am 26. März 2025 (verifiziert): "people love MCP and we are excited to add support across our products. available today in the agents SDK and support for chatgpt desktop app + responses api coming soon!". **Google DeepMind** (Demis Hassabis) bestätigte im April 2025 MCP-Support für Gemini. **Microsoft** kündigte auf der Build 2025 MCP-Integration in Windows 11 und Copilot an. Auch AWS, Cloudflare, Bloomberg beteiligt.
- **Governance**: Im **Dezember 2025** spendete Anthropic MCP an die neu gegründete **Agentic AI Foundation (AAIF)** unter der Linux Foundation – mit Anthropic, OpenAI und Block als Mitgründern, unterstützt von AWS, Bloomberg, Cloudflare, Google und Microsoft als Founding Members → vendor-neutrale Governance.
- **Ökosystem-Skala**: Laut Anthropic (Dez. 2025) >10.000 aktive öffentliche MCP-Server; Support in ChatGPT, Cursor, Gemini, Copilot, VS Code u. v. m. Das offizielle `modelcontextprotocol/servers`-Repo hat ~89.000 GitHub-Stars, das Spec-Repo ~9.100. Das npm-SDK `@modelcontextprotocol/sdk` erreicht laut Drittanbieter-Aggregation (Builder Radar, Aug. 2026) ~195,9 Mio. monatliche Downloads – "The Model Context Protocol npm SDK's 195.9M monthly downloads place it above every other AI-specific package tracked, including the OpenAI SDK (131M) and Anthropic SDK (115.9M)".
- **Enterprise-Case-Study (Block)**: Block (ehem. Square) nutzt MCP im open-source Agent-Framework "**goose**". Laut Anthropic-Customer-Story (claude.com/customers/block, 2025) sparen 75 % der Engineers 8–10+ Stunden pro Woche ("75% of engineers saving 8 to 10+ hours every week using codename goose"); berichtete Zeitersparnis 50–75 % bei alltäglichen Aufgaben. Bloomberg adoptierte MCP organisationsweit (Shawn Edwards, CTO Bloomberg: "we view MCP as a foundational building block for APIs in the era of agentic AI").

**Ehrliche Einordnung**: MCP ist **kein "etabliertes" Muster** im Sinne jahrelanger Produktionshärtung – dafür ist es mit ~1,5 Jahren schlicht zu jung. Aber die Adoptionsgeschwindigkeit ist real, breit und durch harte Zahlen belegt (nicht nur Marketing). Faire Klassifizierung: **Kategorie B** ("aktueller Standard mit schnell wachsender, industrieweiter Adoption") – **mit deutlichen Kategorie-C-Vorbehalten bei Security und Governance-Reife**. Es ist der klare Konvergenzpunkt für LLM-Tool-Integration; ein Vergleich mit der Docker-/Kubernetes-Trajektorie erscheint gerechtfertigt, ist aber noch nicht bewiesen.

**Abgrenzung zu klassischen API-Integrationsmustern**:
- Klassische APIs (REST/gRPC) sind für *deterministische* Aufrufer designt, die vorab wissen, welchen Endpoint sie brauchen. MCP ist für *nicht-deterministische* LLM-Agenten designt, die zur Laufzeit dynamisch entscheiden, welches Tool sie aufrufen – daher die selbstbeschreibenden Tool-/Resource-/Prompt-Primitive mit natürlichsprachlichen Beschreibungen und JSON-Schema-Inputs.
- MCP ersetzt REST/APIs nicht, sondern *legt eine standardisierte Discovery-/Aufruf-Schicht darüber*: Ein MCP-Server ist oft nur ein dünner Adapter vor bestehenden REST-APIs. Der Mehrwert: ein Host spart pro-Modell-Glue-Code; Enterprises kollabieren "Dutzende bespoke Clients auf eine Handvoll MCP-Server".

**Praktische Einschränkungen und offene Probleme (kritisch)**:
- **Security ist das größte Problem**. Dokumentierte Angriffsklassen: **Tool Poisoning** (versteckte Instruktionen in Tool-Metadaten/Beschreibungen, die der Client dem User nicht anzeigt → Credential-Diebstahl, Exfiltration), **(indirekte) Prompt Injection** (bösartige Instruktionen in abgerufenen Daten), **Rug-Pull** (nachträglich geänderte Tool-Definitionen), Supply-Chain-Risiken. OWASP führt "MCP Tool Poisoning" als eigene Angriffskategorie; Kernursache ist die **Trust-Gap zwischen Connect-Time und Runtime** (Tool-Beschreibungen werden einmal geprüft, Antworten fließen ungeprüft in den LLM-Kontext).
- **Konkrete Vorfälle**: **CVE-2025-6514** (JFrog Security Research, Juli 2025): OS-Command-Injection/RCE im weit verbreiteten Paket `mcp-remote`, CVSS 9.6, >437.000 npm-Downloads betroffen – laut The Hacker News "the first documented case of full system compromise achieved through the MCP infrastructure"; gepatcht in v0.1.16 (17. Juni 2025). Zudem ein WhatsApp-MCP-Integrationsvorfall (Nov. 2025), bei dem über ein poisoned Tool Nachrichten-Historien exfiltriert werden konnten.
- **Breite der Schwachstellen**: Eine Sicherheitsanalyse (agent-wars.com, März 2026) von 2.614 gescannten MCP-Implementierungen fand 82 % anfällig für Path-Traversal, 38–41 % ganz ohne Authentifizierung und 30+ CVEs binnen 60 Tagen. Akademische Analysen (arXiv, STRIDE/DREAD-Threat-Modeling über sieben große MCP-Clients) urteilen, dass **client-seitige MCP-Security derzeit unzureichend** ist; Claude Desktop implementiert starke Guardrails, andere (z. B. Cursor) zeigen hohe Anfälligkeit.
- **Governance/Versionierung noch jung**: OAuth 2.1 erst März 2025 nachgerüstet; das Protokoll ist datumsbasiert versioniert (z. B. 2025-11-25) und ändert sich schnell – für Enterprise-Procurement ein Reifegrad-Thema.
- Konsequenz: MCP-Server nur aus vertrauenswürdigen Quellen, Least-Privilege, Metadaten-Validierung, Human-in-the-loop bei destruktiven Tools, MCP-Gateways mit Allowlists.

### 3.9 Zusammenfassende Trade-off-Matrix und Entscheidungslogik

**Trade-off-Matrix** (qualitativ):

| Muster | Latenz | Kopplung | Konsistenz | Komplexität (Dev/Ops) | Skalierbarkeit | Reliability | Reife/Adoption |
|---|---|---|---|---|---|---|---|
| REST | niedrig-mittel | lose | sofort (sync) | niedrig | hoch | hoch | A (sehr hoch) |
| GraphQL | mittel | lose | sofort | mittel-hoch | mittel | mittel-hoch | B (hoch) |
| gRPC | sehr niedrig | mittel-eng | sofort | mittel | sehr hoch | hoch | A (hoch, intern) |
| Webhooks | niedrig (Echtzeit) | lose | eventual | niedrig-mittel | mittel | mittel (Retry nötig) | A |
| Kafka/Streaming | niedrig (ms-s) | sehr lose | eventual (EOS möglich) | hoch | sehr hoch | sehr hoch | A (De-facto-Std) |
| RabbitMQ/Queues | niedrig | lose | eventual | mittel | mittel-hoch | hoch | A |
| ETL (Batch) | hoch (h/Tage) | lose | Snapshot | mittel | hoch | hoch | A |
| ELT | mittel-hoch | lose | Snapshot | mittel | sehr hoch | hoch | A/B |
| CDC (Debezium) | sehr niedrig (s) | lose | eventual + Audit | hoch | hoch | hoch | A |
| ESB (klassisch) | mittel | zentralisiert! | variabel | sehr hoch | niedrig (Bottleneck) | mittel | Legacy |
| iPaaS | mittel | lose | variabel | niedrig-mittel | hoch | hoch | B |
| Service Mesh | sehr niedrig (Infra) | transparent | n/a (Netzwerk) | hoch (Ops) | hoch | sehr hoch | B |
| File/EDI (SFTP/AS2) | hoch (Batch) | sehr lose | Snapshot | niedrig-mittel | hoch | sehr hoch | A (Legacy, robust) |
| MCP | niedrig | lose | sofort (sync Tool-Call) | niedrig-mittel | mittel | mittel (Security!) | B (jung, schnell) |

**Typische Anwendungsfälle**:
- REST: öffentliche Web-APIs, CRUD, breite Client-Kompatibilität.
- GraphQL: mobile/heterogene Frontends, komplexe Datengraphen, BFF.
- gRPC: interne Microservices, hoher Durchsatz, Streaming, polyglott.
- Webhooks: SaaS-Event-Benachrichtigungen, einfache Reaktions-Automation.
- Kafka: Event-Backbone, Event-Sourcing, Echtzeit-Analytics-Ingestion, Entkopplung vieler Systeme.
- RabbitMQ/SQS: Task-Queues, Job-Verteilung, einfache Entkopplung.
- ETL/ELT: Data-Warehouse-/Lakehouse-Beladung, BI, ML-Feature-Pipelines.
- CDC: Echtzeit-DB-Replikation, DB→Event-Stream, Cache-Invalidierung, DWH-Sync.
- iPaaS: SaaS-zu-SaaS, Business-Prozess-Automation ohne tiefe Eng-Ressourcen.
- Service Mesh: Sicherheit/Observability/Traffic in großen K8s-Microservice-Landschaften.
- File/EDI: B2B-Partneraustausch, regulierte Branchen, Legacy-Anbindung.
- MCP: LLM-Agenten-Zugriff auf Tools/Daten/APIs.

**Entscheidungslogik (Decision Tree)**:

1. **Braucht ein LLM-Agent dynamischen Tool-/Datenzugriff?** → **MCP** (mit Security-Governance!). Darunter oft REST-APIs als eigentliche Datenquelle.
2. **Externe Partner / regulierte Branche / kein Echtzeit-API-Zugang?** → **File-based/EDI (SFTP/AS2)**.
3. **Analytische Daten in Warehouse/Lakehouse bringen?**
   - Freshness Stunden/Tage genügt, SaaS-Quellen → **ELT (Fivetran/Airbyte + dbt)**.
   - Sekunden-Latenz / DB-Quellen / Delete-Erfassung / Audit → **CDC (Debezium)**.
   - On-Prem/Compliance (keine Roh-PII) → klassisches **ETL**.
4. **Viele Systeme entkoppeln / Events an mehrere Konsumenten / Replay / hoher Durchsatz?** → **Event-Streaming (Kafka / Redpanda / Pulsar)**. Nur Task-Queue/Routing ohne Replay → **RabbitMQ / SQS / NATS**.
5. **Echtzeit-Benachrichtigung an einen externen Empfänger?** → **Webhooks**.
6. **Synchroner Request/Response nötig?**
   - Öffentlich / Browser / breite Kompatibilität → **REST**.
   - Client braucht flexible, verschachtelte Daten → **GraphQL**.
   - Intern, hochperformant, polyglott, Streaming → **gRPC**.
7. **Viele SaaS-Apps ohne Eng-Team verbinden?** → **iPaaS (MuleSoft / Zapier / Make)**.
8. **Querschnitt Netzwerk-Sicherheit/Observability in K8s?** → **Service Mesh (Istio)** – ergänzend, nicht ersetzend.

**Präsentations-Storyline**:
1. **Problem**: Heterogene Systemlandschaften – Dutzende DBs, SaaS, APIs, Legacy müssen kontinuierlich, frisch und korrekt Daten austauschen. Naives Punkt-zu-Punkt führt zur M×N-Integrations-Explosion ("Enterprise Hairball").
2. **Historie**: File Transfer & Shared DB (früh) → RPC/SOAP → ESB/SOA (zentraler Bus, monolithische Falle) → Microservices + Messaging + Cloud → Modern Data Stack (ELT) → Event-Streaming als Backbone → jetzt LLM-Agenten (MCP).
3. **Aktuelle Muster im Überblick**: die sechs Familien (API, Events, ETL/ELT, CDC, Middleware/iPaaS, File/EDI) + MCP als neue Schicht.
4. **Trade-offs**: synchron vs. asynchron, Batch vs. Echtzeit, Kopplung vs. Einfachheit, Konsistenz vs. Skalierbarkeit.
5. **Entscheidungslogik**: der Decision Tree oben.
6. **Empfehlung**: (siehe unten).

## Recommendations

**Die 4–6 Muster, die man wirklich kennen muss**:
1. **REST (Level 2)** – Lingua franca jeder Integration; ohne geht nichts.
2. **Event-Streaming mit Kafka** – Rückgrat moderner entkoppelter Architekturen; Konzepte (Log, Partitionen, Consumer Groups, Offsets, Zustellsemantik) sind übertragbar auf alle Alternativen.
3. **ELT (Fivetran/Airbyte + dbt + Cloud-Warehouse)** – der Modern-Data-Stack-Standard für Analytics.
4. **CDC (Debezium)** – die Brücke OLTP↔Events/Analytics; wann immer Echtzeit-Sync gebraucht wird.
5. **File-based/EDI** – Legacy, aber in Enterprise/B2B unverzichtbar; unterschätzt und robust.
6. **MCP** – die neue Schicht für LLM-Tool-Zugriff; jetzt lernen, um vorne zu sein.

**Welches ist aktuell besonders relevant?** MCP (wegen des rasanten Momentums und der strategischen Bedeutung für Agenten) und Event-Streaming/Kafka (als reifes Rückgrat, auf dem CDC und EDA aufsetzen). **Am zuverlässigsten unter realen Bedingungen** funktionieren REST Level 2, Kafka und File-based/EDI – sie sind durch Jahre bzw. Jahrzehnte Produktionseinsatz gehärtet. **Am besten zum Selbst-Ausprobieren** eignen sich Webhooks, REST und ein lokaler MCP-Server. **Legacy, aber weiterhin zu kennen**: ESB (um zu verstehen, warum man ihn nicht mehr baut) und EDI/SFTP (weil man ihm in Enterprise/B2B garantiert begegnet).

**Staged next steps**:
- **Kurzfristig (jetzt)**: Bestehende Integrationslandschaft entlang der Achsen (sync/async, batch/realtime) und der sechs Familien kartieren. Für jedes bestehende Punkt-zu-Punkt-Interface prüfen, ob es Kandidat für Entkopplung via Events/CDC ist. Bei neuen Web-APIs REST Level 2 + OpenAPI als Default; gRPC nur intern bei belegtem Performance-Bedarf.
- **Mittelfristig**: Wo Batch-ETL an Freshness-Grenzen stößt, Pilot mit Debezium-CDC auf einer unkritischen DB. Schema Registry (BACKWARD-Kompatibilität als Default) etablieren, bevor Event-Zahl wächst. Reliability-Patterns (Idempotenz, DLQ, Outbox) verbindlich machen.
- **MCP-spezifisch**: In einem *sandboxed*, nicht-produktiven Kontext mit einem MCP-Server experimentieren (z. B. read-only Resource-Server vor einer bestehenden REST-API). Von Anfang an: Least-Privilege, MCP-Gateway mit Allowlist, Human-in-the-loop bei schreibenden/destruktiven Tools, nur vertrauenswürdige Server, gepatchte Abhängigkeiten (vgl. CVE-2025-6514). **Nicht** ungeprüfte Community-Server in produktive Agenten einbinden.

**Benchmarks/Schwellen, die die Empfehlung ändern**:
- Latenzbedarf < Sekunden + Delete-/Audit-Anforderung → von Batch-ETL auf CDC wechseln.
- REST-Chattiness (viele Calls/User-Request) messbar latenz-/kostenrelevant → GraphQL (Client-divers) oder gRPC (intern) evaluieren.
- >~100k msg/s Durchsatz oder Replay-Bedarf → von RabbitMQ/SQS auf Kafka/Redpanda.
- Nachweisbare MCP-Security-Governance (signierte Server, Runtime-Validierung, breite Client-Guardrails) → MCP für sensiblere Produktions-Use-Cases freigeben.

**Was selbst bauen vs. übernehmen**: Praktisch **nichts** von der Infrastruktur selbst bauen – Kafka, Debezium, Airflow, dbt, Airbyte, Kong, Istio, MuleSoft, Camel sind reif und open-source/managed verfügbar. Selbst zu bauen sind nur die *fachlichen* Teile: Event-Schemas/Contracts, dbt-Modelle, Router-/Transformationslogik, MCP-Tool-Definitionen. Für Erst-Experimente am zugänglichsten: **Webhooks** (trivial), **REST** (trivial), ein lokaler **MCP-Server** (SDK in Python/TS, STDIO-Transport, in Stunden lauffähig) und ein **Debezium-Docker-Setup** gegen eine Test-DB.

**MCP – Hype oder Fortschritt?** **Echter Fortschritt**, aber mit Sternchen. Die Adoption ist zu breit und durch harte Zahlen (industrieweite Client-Unterstützung, Linux-Foundation-Governance, Block/Bloomberg-Case-Studies, ~195,9 Mio. SDK-Downloads/Monat) belegt, um bloßer Hype zu sein – MCP löst ein echtes M×N-Problem elegant. Aber es ist noch nicht produktionsgehärtet im Security-/Governance-Sinn (CVE-2025-6514, breite Path-Traversal-/Auth-Lücken); wer es heute produktiv einsetzt, muss die dokumentierten Angriffsvektoren aktiv mitigieren. Realistisch: **jetzt lernen und in sicheren Kontexten einsetzen, produktiv kritische Use-Cases erst mit ausgereifter Governance**.

## Caveats
- **Zeitbezug**: Der MCP-Bereich entwickelt sich extrem schnell; Adoptions-/Governance-Zahlen (Stand Ende 2025/Anfang 2026) können rasch veralten. Die Kafka-LinkedIn-Zahl (7 Bio. Nachrichten/Tag) stammt von 2019 und ist heute höher.
- **Quellenqualität**: Ein Teil der MCP-Adoptionszahlen (npm-Downloads, "10.000+ Server") stammt aus Blog-/Aggregator-Quellen bzw. Anbieter-Kommunikation; GitHub-Stars und offizielle Anthropic/Linux-Foundation-Angaben sind belastbarer. Firmen-Case-Study-Zahlen (Block 50–75 %) sind Anbieter-berichtet, nicht unabhängig auditiert.
- **Performance-Zahlen** (gRPC "77 % schneller", Redpanda "10×", Parquet "22–60×") sind kontextabhängig und teils aus Anbieter- bzw. Benchmark-Quellen (Redpanda-Zahlen werden durch unabhängige Gegentests relativiert); sie illustrieren Größenordnungen, keine Garantien.
- **Kategorisierung A–D** ist eine pragmatische Einordnung nach Produktionsadoption/Evidenz, keine offizielle Taxonomie; Grenzen (v. a. B vs. C bei MCP) sind fließend und interpretationsabhängig.
- **Scope**: RAG-Patterns wurden bewusst ausgeklammert (Thema 4); CDC-Grundlagen nur referenziert (Thema 1).