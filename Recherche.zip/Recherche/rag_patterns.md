# Thema 4: RAG-Patterns von simpel zu komplex — Eine evidenzbasierte Komplexitäts-Eskalation

## TL;DR
- **Starte immer mit Naive RAG plus zwei validierten Verbesserungen (Hybrid Search + Cross-Encoder-Re-Ranking) — das ist der belastbare Produktions-Default (Kategorie A/B).** Für die große Mehrheit der Use Cases reicht diese "Stufe 2" nachweislich aus; jede weitere Komplexitätsstufe muss ihren Mehrwert erst über eine eigene Evaluation beweisen.
- **Die Evidenz ist konsistent asymmetrisch:** Autoren-/Hersteller-Zahlen (Anthropic Contextual Retrieval −49 %/−67 % Retrieval-Fehler; Anthropic Multi-Agent +90,2 %) sind unter unabhängiger Prüfung deutlich domänen- und konfigurationsabhängiger und oft kleiner als beworben. Agentic RAG bringt bei echtem Multi-Hop-QA messbare Gewinne, aber schon zwei Retrieval-Iterationen holen ~95 % davon; Multi-Agent-RAG scheitert in unabhängigen Studien häufig an Fehler-Kaskaden und ~15-fachen Token-Kosten.
- **Eskaliere nur mit Signalen, nicht mit Hype:** Re-Ranking lohnt kaum, wenn Recall@k schon hoch ist; Agentic RAG erst bei nachweislichem Multi-Hop-Bedarf; Graph-Erweiterungen nur bei globalen "Sensemaking"-Fragen; Multi-Agent nur bei breiten, parallelisierbaren, hochwertigen Aufgaben. Ohne eigenes Golden-Set und laufende Evaluation ist jede Eskalation Blindflug.

## Key Findings

1. **Naive RAG (Lewis et al., NeurIPS 2020) ist die Baseline, keine Lösung.** Der Standard-Stack (Chunking → Embedding → Vektor-Index → Top-k-Retrieval → Kontext-Injektion → Generierung) funktioniert gut für einfaktige Faktfragen über homogene Korpora, versagt aber systematisch bei Multi-Hop-Fragen, Aggregation über Dokumente und leidet unter dem "Lost-in-the-Middle"-Effekt (Liu et al., TACL 2024).

2. **Chunking ist unterschätzt, aber Semantic Chunking ist überbewertet.** Recursive Character Splitting (~400–512 Tokens, 10–20 % Overlap) ist der benchmark-validierte Default. Der LLMSemanticChunker erreichte im Chroma Technical Report ("Evaluating Chunking Strategies for Retrieval", 3. Juli 2024) zwar den höchsten Recall (91,9 %) — aber dieser Recall-Vorteil übersetzt sich *nicht* konsistent in bessere End-to-End-Genauigkeit: In einem FloTorch-Test erreichte Semantic Chunking nur 54 % End-to-End-Accuracy gegenüber ~69 % bei Recursive Splitting, und in der Vectara-Studie (NAACL 2025) übertraf Fixed-size Semantic Chunking auf realistischen Datensätzen konsistent. Dieselbe Vectara-Studie fand, dass die Chunking-Konfiguration ähnlich großen oder größeren Einfluss auf die Retrieval-Qualität hat wie die Wahl des Embedding-Modells.

3. **Stufe-2-Verbesserungen sind der "Sweet Spot".** Hybrid Search (BM25+Dense+RRF) und Cross-Encoder-Re-Ranking sind Kategorie A/B (bereits in Thema 2 behandelt). Von den Query-/Kontext-Techniken sind HyDE und LLM-Re-Ranking unabhängig als wirksam bestätigt (ARAGOG-Studie), während Multi-Query und MMR dort *keinen* Vorteil über die Naive-Baseline zeigten. Anthropics Contextual Retrieval wird unabhängig bestätigt, aber die Gewinne sind stark domänenabhängig und oft kleiner als die beworbenen Werte.

4. **Self-RAG/CRAG sind autorenseitig stark, aber nur begrenzt unabhängig validiert.** Beide verlangen entweder Fine-Tuning (Self-RAG) oder einen zusätzlichen Evaluator + Web-Fallback (CRAG) und erhöhen die LLM-Aufrufe deutlich.

5. **Agentic RAG lohnt nur bei echtem Multi-Hop-Bedarf — und weniger Komplexität ist oft besser.** Eine kontrollierte Ablationsstudie (2026) auf 5.000 HotpotQA-Fragen zeigt: iteratives Retrieval hilft, aber zwei Iterationen holen ~95 % der Gewinne, und *festes* Hybrid-Retrieval schlägt regelbasiertes adaptives Routing.

6. **Multi-Agent-RAG ist die am wenigsten gerechtfertigte Stufe.** Die Studie "Why Do Multi-Agent LLM Systems Fail?" (Cemri et al., NeurIPS 2025, arXiv:2503.13657) analysierte 1.600+ annotierte Traces über 7 Frameworks und identifizierte 14 Fehlermodi in 3 Kategorien (Specification Issues 41,8 %, Inter-Agent Misalignment 36,9 %, Task Verification 21,3 %; κ = 0,88), mit dem Kernbefund: *"their performance gains on popular benchmarks are often minimal."* Anthropics eigenes Multi-Agent-System kostet ~15× mehr Tokens. Für die meisten RAG-Use-Cases ist dies Over-Engineering.

7. **Evaluation ist die eigentliche Kernkompetenz.** RAGAS, ARES, TruLens/DeepEval messen Faithfulness, Answer Relevance, Context Precision/Recall. Aber alle LLM-as-Judge-Ansätze haben dieselbe Schwäche, die in Thema 2 bei GraphRAG kritisiert wurde: ohne Ground-Truth/Golden-Set besteht die Gefahr von Selbstbestätigung.

## Details

### 4.1 Naive/Basic RAG — die Baseline

**Ursprung.** Retrieval-Augmented Generation wurde von Lewis et al. ("Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks", NeurIPS 2020) eingeführt: Ein Retriever liefert Passagen, die einen Seq2Seq-Generator konditionieren, wodurch Retrieval Teil der Antwortgenerierung wird. Der taxonomische Rahmen "Naive → Advanced → Modular RAG" stammt aus dem viel zitierten Survey von Gao et al. ("Retrieval-Augmented Generation for Large Language Models: A Survey", arXiv:2312.10997, Dez. 2023).

**Der heutige Standard-Stack.** Chunking → Embedding → Vektor-Index (HNSW, siehe Thema 1) → Top-k-Retrieval → Kontext-Injektion → LLM-Generierung. Dies ist die minimale funktionsfähige Architektur.

**Chunking-Strategien im Detail — was funktioniert, was ist Hype:**

- **Fixed-size Chunking:** Einfachste Methode, fragmentiert aber Semantik. Als Baseline brauchbar, selten optimal — auf realistischen Datensätzen aber überraschend robust (Vectara NAACL 2025: Fixed-size übertraf Semantic konsistent).
- **Recursive Character Splitting:** Der **benchmark-validierte Default**. Chromas Technical Report ("Evaluating Chunking Strategies for Retrieval", Juli 2024) zeigt für Recursive Chunking mit ~400 Tokens und 10–20 % Overlap Recall von ~88–89 % mit `text-embedding-3-large`. Erfordert keine Modellaufrufe, ist schnell und robust.
- **Semantic Chunking:** Erreicht in Chromas Tests den höchsten Recall (LLMSemanticChunker: 91,9 %), aber — und das ist der kritische Punkt — dieser Recall-Vorteil übersetzt sich **nicht konsistent** in bessere End-to-End-Genauigkeit. In einem FloTorch-Test lag Semantic Chunking bei 54 % End-to-End-Accuracy, rund 15 Punkte hinter Recursive Splitting (~69 %). Semantic Chunking ist teuer (Embedding pro Satz) und lohnt sich nur bei hochwertigen, thematisch verwobenen Dokumenten.
- **Document-structure-aware / Page-level Chunking:** In NVIDIAs Benchmark erreichte Page-level Chunking die höchste durchschnittliche Genauigkeit (0,648) bei geringster Varianz — allerdings nur für paginierte Dokumente.

**Wichtigste unabhängige Erkenntnis:** Die Vectara-Studie (NAACL 2025, arXiv:2410.13070) testete 25 Chunking-Konfigurationen mit 48 Embedding-Modellen und fand, dass die Chunking-Konfiguration ähnlich großen oder größeren Einfluss auf die Retrieval-Qualität hat wie die Wahl des Embedding-Modells. Die Kernbotschaft: Erst messen, dann optimieren; kein Chunking-Ansatz ist universell überlegen.

**Bekannte Schwachstellen von Naive RAG:**
- **Lost-in-the-Middle** (Liu et al., "Lost in the Middle: How Language Models Use Long Contexts", TACL 2024, arXiv:2307.03172): Modelle nutzen Information am Anfang/Ende des Kontexts deutlich besser als in der Mitte.
- **Multi-Hop-Schwäche:** Ein einzelner Retrieval-Schritt kann Fragen, deren Antwort über mehrere Dokumente verteilt ist, nicht auflösen.
- **Keine Aggregation** über viele Dokumente ("global sensemaking").
- **Halluzination trotz Kontext:** Auf dem CRAG-Benchmark (Yang et al., "CRAG – Comprehensive RAG Benchmark", arXiv:2406.04744, NeurIPS 2024/KDD Cup 2024, 4.409 QA-Paare) gilt: *"most advanced LLMs achieve ≤34% accuracy on CRAG, adding RAG in a straightforward manner improves the accuracy only to 44%. State-of-the-art industry RAG solutions only answer 63% of questions without any hallucination."*

**Praktische Einsatzfähigkeit:** Naive RAG reicht aus für: einfaktige Faktfragen, homogene/kuratierte Korpora, FAQ-artige Anwendungen, interne Wissensdatenbanken mit klar formulierten Fragen. Sobald Fragen Aggregation, Multi-Hop-Reasoning oder domänenspezifische Terminologie erfordern, stößt Naive RAG an Grenzen.

### 4.2 Verbessertes RAG (Stufe 2)

**Hybrid Search + Re-Ranking** (Details siehe Thema 2). Hybrid Search (BM25+Dense+RRF) ist der Produktions-Default (Kategorie A), Cross-Encoder-Re-Ranking der "höchste ROI nach Hybrid Search". Kritischer Hinweis aus unabhängigen Benchmarks: Hybrid ist kein Automatik-Gewinn — bei schlecht getuntem Fusions-Parameter kann Hybrid schlechter als Dense-only sein; auf Domänen mit hoher lexikalischer Überlappung (z. B. E-Commerce, WANDS-Benchmark) bringt RRF nur +1,7 % NDCG. Erst messen. Ein wichtiger Nuance-Befund aus ARAGOG: Cohere Rerank zeigte auf dem dortigen Korpus *keinen* Vorteil über die Naive-Baseline, während LLM-basiertes Re-Ranking Verbesserung brachte — kommerzielle Reranker sind nicht universell überlegen.

**Query Transformation Patterns:**
- **HyDE** (Gao et al., "Precise Zero-Shot Dense Retrieval without Relevance Labels", ACL 2023, arXiv:2212.10496): Ein LLM generiert ein hypothetisches Antwortdokument, dessen Embedding zur Suche genutzt wird; ein kontrastiv trainierter Encoder filtert die Halluzinationen heraus. **Evidenz:** In der unabhängigen ARAGOG-Studie (arXiv:2404.01037) verbesserte HyDE die Retrieval-Präzision signifikant über die Naive-Baseline. Nachteil: zusätzliche LLM-Latenz (25–60 % mehr auf kleinen LLMs), Halluzinationsrisiko bei Nischenfragen.
- **Multi-Query-Retrieval:** Eine Query wird zu mehreren umformuliert. **Evidenz:** In ARAGOG *unterlegen* gegenüber Naive RAG — ein gutes Beispiel dafür, dass "aufwendiger" nicht "besser" bedeutet.
- **Query Rewriting/Expansion:** Konzeptuell wertvoll bei mehrdeutigen/unterspezifizierten Queries.

**Kontextuelle Verbesserungen:**
- **Contextual Retrieval** (Anthropic, "Contextual Retrieval in AI Systems", Sept. 2024): Jedem Chunk wird vor dem Embedding ein kurzer, dokumentbezogener Kontext vorangestellt (via LLM, kostengünstig durch Prompt Caching). **Anthropics Eigenzahlen** (Metrik: Top-20-Chunk-Retrieval-Failure-Rate): Contextual Embeddings allein −35 % (5,7 % → 3,7 %); Contextual Embeddings + Contextual BM25 −49 % (5,7 % → 2,9 %); zusätzlich Re-Ranking −67 % (5,7 % → 1,9 %). **Kritische Evidenzprüfung:** Eine direkte Reproduktion auf Anthropics eigenem Datensatz (Denser Retriever, 248 Queries/737 Docs) *bestätigt* den Effekt (Recall@20: BM25 70,5 → 89,3; Voyage 90,1 → 94,5; +Rerank 96,1) und matcht die Cookbook-Zahlen. Die unabhängige Vergleichsstudie von Merola & Singh ("Reconstructing Context", arXiv:2504.19754, ECIR-2025-Workshop) auf NFCorpus/MS MARCO mit Open-Source-Embeddern und einem kleinen quantisierten Phi-3.5-mini findet jedoch nur *kleine* Gewinne (z. B. NDCG@5 0,317 vs. 0,309 gegen Late Chunking) und kommt zum Schluss: *"contextual retrieval preserves semantic coherence more effectively but requires greater computational resources"* — der Nutzen rechtfertigt den höheren Compute-Aufwand nicht klar, und nichts nahe 49/67 % wurde beobachtet. Kritiker weisen zudem darauf hin, dass Anthropics Gewinne stark domänenabhängig sind (bis 84 % bei Fiction, aber ~41 % bei "Codebases-Vague", teils kein Zusatznutzen bei ArXiv-Papers auf Top-20). **Fazit: wirksam, aber nicht der beworbene Wunder-Hebel; der Re-Ranking-Anteil trägt oft den größten Teil bei.**
- **Parent-Document / Sentence-Window Retrieval ("Small-to-Big"):** Klein embedden/retrieven, groß zurückgeben. In LangChain (`ParentDocumentRetriever`) und LlamaIndex (`SentenceWindowNodeParser`) verfügbar. In ARAGOG erzielte Sentence-Window-Retrieval hohe Retrieval-Präzision (allerdings ohne konsistente Übersetzung in Answer-Similarity).
- **RAPTOR** (Sarthi et al., ICLR 2024, arXiv:2401.18059): Rekursives Clustern/Zusammenfassen zu einem Baum; verbesserte QuALITY um 20 Punkte absolut mit GPT-4 (82,6 % Test / 76,2 % Hard). Kategorie B für Langdokument-QA — aber Vorsicht: auf dem Enterprise-Benchmark HERB schnitt RAPTOR *schlechter* ab als eine einfache Vector-Baseline.

**Self-RAG / Corrective RAG:**
- **Self-RAG** (Asai et al., ICLR 2024, arXiv:2310.11511): LLM wird mit "Reflection Tokens" trainiert, um On-Demand-Retrieval und Selbstkritik (IsREL/IsSUP/IsUSE) zu steuern. **Evidenz:** ICLR-2024-Oral; Self-RAG 7B/13B übertreffen Llama2 und Standard-RAG auf Open-Domain-QA, Reasoning und Fact-Verification. **Einschränkung:** Erfordert Fine-Tuning (separates Critic- + Generator-Modell, GPT-4-annotierte Trainingsdaten), hohe Komplexität, Segment-weise Beam-Search bei Inferenz.
- **CRAG** (Yan et al., "Corrective Retrieval Augmented Generation", arXiv:2401.15884, Jan. 2024): Leichtgewichtiger Retrieval-Evaluator (fein-getuntes T5-large) mit Aktionen Correct/Incorrect/Ambiguous + Decompose-then-Recompose + Web-Fallback; plug-and-play, keine LLM-Änderung nötig. **Evidenz:** Autorenzahlen zeigen +19,0 % (PopQA), +14,9 FactScore (Biography), +36,6 % (PubHealth) über Standard-RAG. **Einschränkung:** zusätzliche LLM-Aufrufe → Latenz/Kosten; überwiegend autorenevaluiert.

**Evidenzbewertung Stufe 2:** Hybrid Search + Re-Ranking = unabhängig auf mehreren Benchmarks bestätigt, produktiv (A/B). HyDE, Sentence-Window = unabhängig bestätigt (B). Contextual Retrieval, RAPTOR = teils unabhängig reproduziert, aber kontextabhängig (B–C). Self-RAG/CRAG = überwiegend autorenevaluiert, begrenzt unabhängig (C).

### 4.3 Agentic RAG (Stufe 3)

**Abgrenzung:** Agentic RAG unterscheidet sich von klassischem RAG durch (1) dynamische Entscheidung *ob/wann* retrievt wird, (2) iteratives/mehrstufiges Retrieval, (3) Tool-Use (Retrieval als *ein* Tool). Überblick: Singh et al., "Agentic RAG: A Survey on Agentic RAG", arXiv:2501.09136.

**ReAct-Pattern** (Yao et al., "ReAct: Synergizing Reasoning and Acting in Language Models", ICLR 2023, arXiv:2210.03629): Verschränkte Thought-Action-Observation-Schritte. Grundlage vieler agentischer Systeme; auf HotpotQA/Fever (mit Wikipedia-API) schlägt ReAct reine Action-Generierung und ist mit Chain-of-Thought konkurrenzfähig, wobei die Kombination ReAct+CoT am besten abschneidet.

**Multi-Step/Iterative Retrieval:** Bei Multi-Hop-QA (HotpotQA, 2WikiMultiHopQA, MuSiQue) reicht ein Schritt nicht, weil spätere Retrieval-Schritte von Zwischenergebnissen abhängen. **Kritische unabhängige Evidenz** — die Ablationsstudie "Dissecting Agentic RAG: A Component Ablation for Multi-Hop QA with a Local 7B Model" (arXiv:2606.21553, 2026) auf 5.000 HotpotQA-Distractor-Fragen mit Qwen2.5-7B-Instruct:
- Volle Agentic-Pipeline: EM 53,2 % / F1 61,6 % vs. Single-Pass-Dense-Baseline EM 43,1 % / F1 54,0 %.
- **Aber:** Festes Hybrid-Retrieval (RRF) schlägt regelbasiertes adaptives Routing konsistent (+1,8 EM, +1,9 F1); die Routing-Heuristik "over-routet" zu BM25.
- **Zwei Retrieval-Iterationen holen ~95 % der Gewinne von fünf** — mehr Iterationen lohnen kaum.
- Die Hybrid-only-Variante erreicht sogar EM 55,0 % / F1 63,5 % ganz ohne proprietäre API-Calls.

**Query Routing** (Details Thema 2, dort Kategorie C für komplexe LLM-Router). Die obige Studie bestätigt: einfaches festes Hybrid schlägt regelbasiertes Routing.

**Tool-Use/Function-Calling & MCP:** Retrieval wird zu einem Tool unter mehreren. Hier greift **MCP (Model Context Protocol)** aus Thema 3 (Kategorie B mit Security-Vorbehalten) als standardisiertes Integrationsmuster für LLM-Tool-Zugriff.

**Evidenzlage — wann lohnt der Mehraufwand?** Agentic RAG rechtfertigt sich bei echtem Multi-Hop-/kompositionalem Bedarf. Der Qualitätsgewinn (~+10 EM-Punkte auf HotpotQA) ist real, aber die Erkenntnis lautet: **die einfachste agentische Konfiguration (festes Hybrid + max. 2 Iterationen) ist oft die stärkste**; adaptives Routing und tiefe Loops fügen Komplexität ohne proportionalen Gewinn hinzu.

### 4.4 Graph-basierte RAG-Erweiterungen (Stufe 4 — kurz)

GraphRAG wurde in Thema 2 **ausführlich und kritisch** behandelt (Kategorie C: LLM-as-Judge-Evaluation ohne Ground-Truth, ~1000× teurer im Indexaufbau, kein konsistenter Gewinner ggü. normalem RAG laut Han et al., SIGKDD 2026). Hier nur als Stufe der Leiter referenziert.

**Neue Erkenntnisse zu leichtgewichtigen Alternativen seit der letzten Recherche:**
- **LazyGraphRAG** (Microsoft Research, Nov. 2024): Verschiebt die teure LLM-Summarisierung auf Query-Zeit; Indexkosten identisch zu Vector-RAG (~0,1 % von Full-GraphRAG). In Microsofts eigenem BenchmarkQED gewann LazyGraphRAG alle 96 Vergleiche (mit einer Ausnahme statistisch signifikant). **Kritisch:** Es handelt sich um herstellereigene Benchmarks (BenchmarkQED wurde von Microsoft *zur Evaluation von LazyGraphRAG* gebaut) — dieselbe Vorsicht wie bei GraphRAG gilt. Seit Juni 2025 in Microsoft Discovery/Azure Local integriert.
- **LightRAG** (Guo et al., HKUDS, arXiv:2410.05779, EMNLP 2025): Dual-Layer Graph+Vector, inkrementelle Updates, Indexkosten nahe reinem Embedding.
- **NodeRAG / Fast-GraphRAG / nano-graphrag:** Weitere leichtgewichtige Open-Source-Varianten (Fast-GraphRAG: ~6× günstiger als Full-GraphRAG im "Wizard of Oz"-Test).
- Ein GraphRAG-Bench-Ergebnis (zitiert für ICLR'26) fand nur +4,5 % auf HotpotQA bei 2,3× höherer Latenz — Graph glänzt bei komplexen relationalen/globalen Fragen, nicht bei einfachen Lookups.

**Wann gerechtfertigt:** Nur bei globalen "Sensemaking"-Fragen über den gesamten Korpus oder stark relationalen Daten (Entity-Beziehungen). Für lokale Faktfragen ist Graph-RAG unnötige Komplexität — zuerst Hybrid Retrieval ausschöpfen. Kostenfaktor ist dank LazyGraphRAG/LightRAG kein K.o.-Kriterium mehr, aber auch kein Grund zum Default.

### 4.5 Multi-Agent RAG-Architekturen (Stufe 5 — die komplexeste)

**Patterns:** Spezialisierte Sub-Agenten (Query-Verständnis, Retrieval, Synthese) unter einem Orchestrator (Orchestrator-Worker-Pattern).

**Frameworks — Produktionsreife vs. Demo:**
- **LangGraph:** In mehreren Vergleichen als produktionsreifste Option eingestuft (Graph-State, Checkpointing, LangSmith-Observability, Human-in-the-Loop). Steilste Lernkurve, beste Token-Effizienz. Ein einfacher ReAct-Agent braucht in LangGraph ~120 Zeilen vs. ~40 in Smolagents — der Preis für explizite Kontrolle.
- **CrewAI:** Rollenbasiert, schnellstes Prototyping, intuitiv, aber schwächere Fehlerbehandlung bei partiellen Ausfällen.
- **AutoGen (AG2 / Microsoft Agent Framework):** Konversationsbasiert, höchster Token-Overhead (3–5× LangGraph), lange als experimentell eingestuft; seit April 2026 mit Semantic Kernel zum Microsoft Agent Framework verschmolzen.

**Kritische Evidenzlage:** Die zentrale unabhängige Studie ist **"Why Do Multi-Agent LLM Systems Fail?" (Cemri et al., UC Berkeley u. a., NeurIPS 2025, arXiv:2503.13657)**: Analyse von 1.600+ annotierten Traces über 7 Frameworks, 14 Fehlermodi (MAST-Taxonomie, κ = 0,88) in 3 Kategorien (Specification Issues 41,8 %, Inter-Agent Misalignment 36,9 %, Task Verification 21,3 %). Kernbefund wörtlich: *"Despite enthusiasm for Multi-Agent LLM Systems (MAS), their performance gains on popular benchmarks are often minimal."* Fehler kaskadieren, statt sich auszugleichen (Error-Compounding, Konformitäts-Bias, geteilte Halluzinationen).

**Der Kontrast — Anthropics Multi-Agent-Research-System** ("How we built our multi-agent research system", Juni 2025): Orchestrator (Claude Opus 4) mit 3–5 parallelen Claude-Sonnet-4-Subagenten; *"outperformed single-agent Claude Opus 4 by 90.2% on our internal research eval"*, wobei *"token usage by itself explains 80% of the variance"*. **Aber:** *"multi-agent systems use about 15× more tokens than chats."* Anthropic selbst betont, dass Aufgaben, "die geteilten Kontext oder viele Abhängigkeiten zwischen Agenten erfordern, kein guter Fit sind". Die +90,2 %-Zahl ist herstellereigen und auf breite, parallelisierbare Research-Fragen zugeschnitten; das publizierte Design hat zudem keine Circuit-Breaker/Kostendeckel.

**Wann gerechtfertigt vs. Over-Engineering:** Gerechtfertigt nur bei (1) breiten, in unabhängige Teilfragen zerlegbaren Aufgaben, (2) hohem Antwortwert (Legal Due Diligence, Competitive Intelligence, Biomedizin-Literaturreview), (3) Informationsmenge > einzelnes Kontextfenster. Für die meisten RAG-Use-Cases (Q&A, Support, Enterprise-Search) ist Multi-Agent-RAG **Over-Engineering** — höhere Kosten und Fehleranfälligkeit ohne proportionalen Qualitätsgewinn.

### 4.6 Evaluation von RAG-Systemen

**Frameworks:**
- **RAGAS** (Es et al., 2024): Am weitesten verbreitet; misst Faithfulness, Answer Relevancy, Context Precision, Context Recall; referenzfrei (kein Ground-Truth nötig), LLM-as-Judge. Faithfulness läuft über eine mehrstufige Claim-Extraktion + NLI-Verifikation gegen den Kontext.
- **ARES** (Saad-Falcon et al., NAACL 2024, arXiv:2311.09476): Fein-getunte kleinere LLM-Judges (DeBERTa-Varianten) + Prediction-Powered Inference; laut eigener Studie schlägt ARES *"existing automated evaluation approaches like RAGAS by 59.3 and 14.4 percentage points on average across context relevance and answer relevance evaluation accuracy, respectively."* (Autoreneigene Zahl — mit derselben Vorsicht zu lesen.)
- **TruLens:** "RAG Triad" (Groundedness, Answer Relevance, Context Relevance).
- **DeepEval, Arize Phoenix, LangSmith:** weitere etablierte Optionen.

**Wichtige Metriken:** Faithfulness/Groundedness (Antwort durch Kontext gedeckt?), Answer Relevance (beantwortet die Frage?), Context Precision (ist retrievter Kontext fokussiert?), Context Recall (enthält Kontext die Antwort?). Ergänzend Retrieval-Metriken: Recall@k, MRR, NDCG@k, Hit Rate.

**Warum Evaluation entlang der Stufen essenziell ist:** Der rote Faden dieser Recherche ist, dass jede Komplexitätsstufe ihren Mehrwert *messbar* nachweisen muss. Ohne Messung wird man komplexer statt besser.

**Golden-Set vs. LLM-as-Judge — kritisch:** LLM-as-Judge (RAGAS, TruLens) skaliert und braucht kein manuelles Labeling, hat aber genau die Schwäche, die in Thema 2 bei GraphRAG kritisiert wurde: **ohne Ground-Truth droht Selbstbestätigung** (das LLM bewertet, was ein LLM erzeugt hat). Ein handkuratiertes Golden-Set (20–50+ repräsentative Query-Antwort-Paare) ist teurer, aber der Goldstandard für Regressionstests. Best Practice: kleines Golden-Set als Anker + LLM-as-Judge für Skalierung; Judge-Scores gegen das Golden-Set kalibrieren.

### 4.7 Komplexitäts-Eskalations-Matrix und Entscheidungslogik

| Kriterium | Naive RAG | Verbessertes RAG (Stufe 2) | Agentic RAG | Graph-RAG | Multi-Agent-RAG |
|---|---|---|---|---|---|
| **Antwortqualität** | Baseline (~44 % auf CRAG) | Deutlich besser (Hybrid+Rerank, HyDE) | +~10 EM auf Multi-Hop | Nur bei globalen Fragen | Herstellerzahl +90,2 %, unabh. oft minimal |
| **Latenz** | Niedrigste | Niedrig-mittel | Hoch (iterativ) | Mittel (Query-Zeit) | Sehr hoch (parallel) |
| **Kosten** | Niedrigste | Niedrig (+Rerank) | Mittel-hoch | Index teuer (Full) / niedrig (Lazy/Light) | ~15× Chat |
| **Implementierung** | Trivial | Gering (Frameworks) | Mittel | Hoch | Sehr hoch |
| **Wartung/Debugging** | Einfach | Einfach-mittel | Schwer (Traces) | Schwer | Sehr schwer (Kaskaden) |
| **Query-Typen** | Einfaktig, FAQ | Die meisten Produktiv-Fälle | Multi-Hop, kompositional | Global/relational | Breit, parallelisierbar |
| **Reifegrad** | Sehr hoch | Sehr hoch (A/B) | Wachsend (B–C) | C (kritisch) | C–D (Demo-lastig) |

**Praktischer Decision Tree mit konkreten Signalen:**

1. **Immer starten mit:** Naive RAG + Recursive Chunking (512 Tokens, 10–20 % Overlap) + Hybrid Search (BM25+Dense+RRF). Golden-Set aufsetzen, messen.
2. **Re-Ranking hinzufügen, wenn** Recall@k hoch, aber Precision niedrig ist (relevante Docs sind im Candidate-Set, aber nicht oben). Faustregel im Stil von Thema 2: **wenn Recall@3 bereits >0,9, lohnt Re-Ranking kaum**; wenn Recall@20 hoch, aber Recall@3 niedrig → Re-Ranking ist der höchste ROI.
3. **Query-Transformation (HyDE) hinzufügen, wenn** Queries konzeptuell/vage sind und Recall trotz Hybrid niedrig bleibt. Multi-Query eher meiden (unabh. kein Nachweis).
4. **Contextual Retrieval / Parent-Document erwägen, wenn** Chunks isoliert Kontext verlieren (z. B. Finanzberichte, Codebases) — aber erst A/B gegen Baseline messen (der Zusatznutzen ist stark domänenabhängig).
5. **Agentic RAG (iterativ) erst, wenn** ein messbarer Anteil der Fragen echte Multi-Hop-Reasoning erfordert (Signal: Naive/Hybrid scheitert systematisch bei "welches X, das mit Y verbunden ist, hat Eigenschaft Z"). Dann: festes Hybrid + max. 2 Iterationen, kein komplexes LLM-Routing.
6. **Graph-Erweiterungen erst, wenn** globale "Sensemaking"-Fragen über den ganzen Korpus dominieren *und* Hybrid nachweislich versagt. Dann LazyGraphRAG/LightRAG vor Full-GraphRAG (Kostenfaktor ~1000× im Index).
7. **Multi-Agent erst, wenn** Aufgaben breit + parallelisierbar + hochwertig sind und die ~15×-Token-Kosten tragbar sind. Sonst: nicht.

## Recommendations

**Stufe, mit der man IMMER starten sollte:** Naive RAG mit Recursive Character Splitting + Hybrid Search (BM25+Dense+RRF). Das ist die belastbare, günstige, wartbare Baseline. Ergänze sofort ein Golden-Set und automatisierte Evaluation (RAGAS + kleines handkuratiertes Set).

**Die 5 Patterns/Techniken, die man wirklich kennen muss:**
1. **Recursive Chunking** (Default) + Bewusstsein, dass Chunking ähnlich wichtig ist wie das Embedding-Modell.
2. **Hybrid Search (BM25+Dense+RRF)** — der Produktions-Default.
3. **Cross-Encoder-Re-Ranking** — höchster ROI nach Hybrid Search.
4. **HyDE** — die einzige Query-Transformation mit robustem unabhängigem Wirknachweis.
5. **RAG-Evaluation** (RAGAS + Golden-Set) — die Meta-Kompetenz, ohne die Eskalation Blindflug ist.

**Konkrete Eskalations-Signale:**
- Re-Ranking: niedrige Precision bei hohem Recall (aber nicht, wenn Recall@3 schon >0,9).
- Agentic: systematisches Scheitern bei Multi-Hop-Fragen.
- Graph: Dominanz globaler/relationaler Fragen bei nachgewiesenem Hybrid-Versagen.
- Multi-Agent: breite, parallelisierbare, hochwertige Aufgaben mit tragbaren Kosten.

**Oft Over-Engineering für die meisten Use Cases:** Multi-Agent-RAG (Stufe 5) und Full-GraphRAG (Stufe 4) sowie komplexe LLM-Query-Router und Multi-Query-Retrieval. Diese klingen fortgeschritten, liefern aber unter unabhängiger Prüfung selten proportionalen Mehrwert.

**Bestes Pattern zum Selbst-Implementieren/Ausprobieren:** **Hybrid Search + Re-Ranking** — geringer Aufwand, großer Effekt, in LangChain/LlamaIndex/Haystack fertig verfügbar, sofort messbar. Für ein lehrreiches "Aha" eignet sich **HyDE** (wenige Zeilen, sichtbare Retrieval-Verbesserung). Was man *nicht* selbst bauen sollte: Multi-Agent-Orchestrierung (LangGraph übernehmen) und Vektor-Index/HNSW (siehe Thema 1).

**Storyline für die Präsentation:**
1. **Problem:** Naive RAG reicht oft nicht (Lost-in-the-Middle, Multi-Hop, Halluzination; CRAG: einfaches RAG nur ~44 %, Industrie-SOTA ~63 %).
2. **Eskalationsstufen im Überblick:** Die 5-Stufen-Leiter (Naive → Verbessert → Agentic → Graph → Multi-Agent).
3. **Wann welche Stufe:** Decision Tree mit konkreten Signalen.
4. **Empirischer Vergleich:** Die Matrix — mit dem wiederkehrenden Muster, dass unabhängige Zahlen kleiner sind als Herstellerzahlen (Contextual Retrieval, Multi-Agent).
5. **Praktische Bewertung:** Komplexität kostet Latenz, Geld, Debugging — und liefert nur mit Evidenz Mehrwert.
6. **Empfehlung:** Starte einfach, miss alles, eskaliere nur mit Signal.

## Caveats

- **Asymmetrie der Evidenz:** Konsistent mit den vorherigen drei Recherchen erwiesen sich Hersteller-/Autoren-Zahlen (Anthropic −49 %/−67 % und +90,2 %, LazyGraphRAG 96/96 Siege, CRAG +19–36 %, ARES +59,3 pp über RAGAS) als optimistischer bzw. konfigurationsabhängiger als unabhängige Evaluationen. Wo möglich wurde dies markiert; für einige Patterns (Self-RAG, CRAG, LazyGraphRAG) fehlen noch große, rigoros peer-reviewte, unabhängige Reproduktionen.
- **Contextual Retrieval speziell:** Direkte Reproduktion auf Anthropics *eigenem* Datensatz bestätigt den Effekt, die unabhängige Vergleichsstudie (Merola & Singh, arXiv:2504.19754) findet aber nur kleine Gewinne und zweifelt am Kosten-Nutzen-Verhältnis — allerdings mit sehr kleinem Testset (50 Queries/300 Docs) und kleinem quantisiertem LLM. Kein großer, domänenübergreifender, peer-reviewter Nachweis der 49/67 %-Größenordnung existiert.
- **Benchmark-Grenzen:** Viele Zahlen stammen aus akademischen Multi-Hop-Benchmarks (HotpotQA, 2Wiki, MuSiQue), deren Übertragbarkeit auf Enterprise-Daten begrenzt ist. Auf einem heterogenen Enterprise-Benchmark (HERB) schnitten RAPTOR und GraphRAG *schlechter* ab als eine einfache Vector-Baseline.
- **Sekundärquellen:** Einige praxisnahe Zahlen (Chroma/NVIDIA/FloTorch-Chunking, Framework-Vergleiche, Denser-Reproduktion) stammen aus Vendor-Blogs bzw. Aggregatoren; die zugrunde liegenden Primärstudien (Chroma Technical Report, Vectara NAACL 2025 arXiv:2410.13070, ARAGOG arXiv:2404.01037, Cemri et al. arXiv:2503.13657, Merola & Singh arXiv:2504.19754, "Dissecting Agentic RAG" arXiv:2606.21553) wurden referenziert.
- **Schnell bewegtes Feld:** Framework-Versionen (LangGraph, CrewAI, AutoGen/MAF) und Reifegrade ändern sich monatlich; die Produktionsreife-Einschätzungen sind Stand Mitte 2026.
- **Kein Ersatz für eigene Messung:** Alle Schwellwerte (z. B. Recall@3 >0,9) sind Orientierung, kein Dogma — die einzig verlässliche Grundlage ist ein eigenes Golden-Set auf den eigenen Daten.