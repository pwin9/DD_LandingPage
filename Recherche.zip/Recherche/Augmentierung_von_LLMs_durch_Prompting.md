# Literaturübersicht: Augmentierung von LLMs durch Prompting (Teil 1 von 3: Prompting)

## TL;DR
- **Prompt-basierte Augmentierung verbessert LLM-Ausgaben ausschließlich über die Gestaltung der Eingabe** – ohne Gewichtsänderung und ohne externe Tools/Retrieval; der maßgebliche aktuelle Referenzrahmen ist *The Prompt Report* (Schulhoff et al., 2024, arXiv:2406.06608), das laut Abstract „a taxonomy of 58 text-only prompting techniques, and 40 techniques for other modalities" bereitstellt.
- Die wirkungsvollsten und meistzitierten Techniken sind **In-Context/Few-Shot-Learning** (Brown et al., 2020), **Chain-of-Thought** (Wei et al., 2022) mit **Zero-Shot-CoT** (Kojima et al., 2022) und **Self-Consistency** (Wang et al., 2022, +17,9 % auf GSM8K), sowie strukturierte Erweiterungen (**Tree-of-Thoughts**, **Graph-of-Thoughts**) und iterative/agentische Verfahren (**Self-Refine**, **ReAct**).
- Die zentrale Schwäche ist **Brüchigkeit**: Reine Formatänderungen können die Genauigkeit „with performance differences of up to 76 accuracy points when evaluated using LLaMA-2-13B" verschieben (Sclar et al., 2023); hinzu kommen Sicherheitsrisiken durch **Prompt Injection** (Perez & Ribeiro, 2022; Greshake et al., 2023).

## Key Findings
1. **Zwei umfassende Surveys bilden das Fundament**: *The Prompt Report* (Schulhoff et al., 2024) und *A Systematic Survey of Prompt Engineering in Large Language Models: Techniques and Applications* (Sahoo et al., 2024, arXiv:2402.07927).
2. **Reasoning-Techniken dominieren die Wirksamkeitsforschung**: CoT und seine Varianten sind die am besten belegten Methoden zur Leistungssteigerung bei komplexen Aufgaben.
3. **Automatische Prompt-Optimierung** (APE, OPRO, PromptBreeder, DSPy) verlagert das Prompt-Design vom manuellen Handwerk zur algorithmischen Suche.
4. **Empirische Evidenz wird zunehmend kritisch**: Persona-Prompting und CoT bei dedizierten Reasoning-Modellen zeigen begrenzten oder keinen Nutzen.
5. **Industrie-Leitfäden** (OpenAI, Anthropic, Google) systematisieren Best Practices für die praktische Anwendung und sind als ergänzende, nicht peer-reviewte Ressourcen einzuordnen.

## Details

### 1. Grundlegende Surveys und Taxonomien

**The Prompt Report: A Systematic Survey of Prompting Techniques** — Sander Schulhoff, Michael Ilie, Nishant Balepur et al. (2024), arXiv:2406.06608. Umfassendste systematische Übersicht (PRISMA-Methodik, Datenquellen arXiv/Semantic Scholar/ACL). Verbatim aus dem Abstract: „We present a comprehensive vocabulary of 33 vocabulary terms, a taxonomy of 58 text-only prompting techniques, and 40 techniques for other modalities." Beschränkt sich bewusst auf **diskrete Präfix-Prompts (Hard Prompts)** und schließt gradientenbasierte (Soft-Prompt-/Fine-Tuning-)Verfahren weitgehend aus. Zeigt, dass die Effektivität stark von Exemplar-Auswahl, -Reihenfolge, Label-Verteilung und Format abhängt. **Empfehlung als zentrales Gerüst der Arbeit.**

**A Systematic Survey of Prompt Engineering in Large Language Models: Techniques and Applications** — Pranab Sahoo et al. (2024), arXiv:2402.07927. Kategorisiert Techniken nach Anwendungsbereich (über 40 Techniken; die genaue Zahl – je nach Zählweise 41 bzw. 44 – sollte vor der Zitation im Volltext geprüft werden), mit Taxonomie-Diagramm und Tabellen zu Modellen und Datensätzen. Ergänzt *The Prompt Report* um eine anwendungsorientierte Sichtweise.

**Demystifying Chains, Trees, and Graphs of Thoughts** — Maciej Besta et al. (2024), arXiv:2401.14295. Fokussiert auf die **Topologie** strukturierter Reasoning-Prompts; erste Taxonomie/Analyse „structure-enhanced prompting methods".

**A Survey on In-context Learning** — Qingxiu Dong, Lei Li, Damai Dai et al. (2022/2024), arXiv:2301.00234. Erste Übersicht zum In-Context-Learning; formalisiert ICL, behandelt Demonstrationsauswahl und theoretische Interpretation (mehrfach überarbeitet, aktuellste Version v6, Okt. 2024).

**Towards Reasoning in Large Language Models: A Survey** — Jie Huang, Kevin Chen-Chuan Chang (2022), arXiv:2212.10403. Überblick über Reasoning-Methoden inkl. Problemdekomposition (Least-to-Most, Decomposed, Successive Prompting).

**Exploring Prompt Engineering: A Systematic Review with SWOT Analysis** — arXiv:2410.12843. Nützlich für eine Stärken-/Schwächen-Betrachtung.

### 2. Schlüsseltechniken und ihre Ursprungsarbeiten

#### Few-Shot / In-Context Learning (ICL)
**Language Models are Few-Shot Learners** — Tom B. Brown, Benjamin Mann, Nick Ryder et al. (2020), NeurIPS 2020, arXiv:2005.14165. Die GPT-3-Arbeit; führte In-Context-Learning ein. Verbatim: „For all tasks, GPT-3 is applied without any gradient updates or fine-tuning, with tasks and few-shot demonstrations specified purely via text interaction with the model." Modell mit 175 Mrd. Parametern. **Grundlage aller nachfolgenden Prompting-Forschung** (Unterscheidung Zero-/One-/Few-Shot).

#### Chain-of-Thought (CoT) und Varianten
**Chain-of-Thought Prompting Elicits Reasoning in Large Language Models** — Jason Wei, Xuezhi Wang, Dale Schuurmans et al. (2022), NeurIPS 2022, arXiv:2201.11903. Wenige CoT-Demonstrationen (explizite Zwischenschritte) verbessern arithmetisches, Commonsense- und symbolisches Reasoning erheblich. Konkret erreichte **PaLM 540B mit 8-Shot-CoT (plus externem Rechner) 58 % auf GSM8K** und übertraf damit den vorherigen State-of-the-Art von 55 % (feingetuntes GPT-3 175B mit Verifier, Cobbe et al. 2021).

**Large Language Models are Zero-Shot Reasoners** — Takeshi Kojima, Shixiang Shane Gu, Machel Reid, Yutaka Matsuo, Yusuke Iwasawa (2022), NeurIPS 2022, arXiv:2205.11916. **Zero-Shot-CoT**: Der einfache Zusatz „Let's think step by step" ohne Beispiele steigert die Reasoning-Leistung über MultiArith, GSM8K, AQUA-RAT, SVAMP, Last Letter und Coin Flip deutlich.

**Self-Consistency Improves Chain of Thought Reasoning in Language Models** — Xuezhi Wang, Jason Wei, Dale Schuurmans et al. (2022), ICLR 2023, arXiv:2203.11171. Ersetzt Greedy-Decoding durch Sampling mehrerer Reasoning-Pfade und Marginalisierung (Mehrheitsentscheid). Verbatim berichtete Gewinne: „GSM8K (+17.9%), SVAMP (+11.0%), AQuA (+12.2%), StrategyQA (+6.4%) and ARC-challenge (+3.9%)".

**Auto-CoT (Automatic Chain-of-Thought Prompting)** — Zhang et al. (2022), arXiv:2210.03493. Clustert Testfragen zur Diversität und generiert Demonstrationen automatisch per Zero-Shot-CoT, wodurch manuelles Exemplar-Design entfällt.

#### Baumartige und graphbasierte Reasoning-Frameworks
**Tree of Thoughts: Deliberate Problem Solving with Large Language Models** — Shunyu Yao, Dian Yu, Jeffrey Zhao, Izhak Shafran, Thomas L. Griffiths, Yuan Cao, Karthik Narasimhan (2023), NeurIPS 2023, arXiv:2305.10601. Verallgemeinert CoT zu einer **Baumstruktur von „Gedanken"** mit Suchalgorithmen (BFS/DFS), Look-ahead und Backtracking; explizit inspiriert von der „System-2"-Planung (Newell/Simon).

**Graph of Thoughts: Solving Elaborate Problems with Large Language Models** — Maciej Besta, Nils Blach, Ales Kubicek et al. (2024), AAAI 2024 (Proc. AAAI, Vol. 38, S. 17682–17690), arXiv:2308.09687. Modelliert die vom LLM erzeugte Information als **beliebigen Graphen** (Knoten = Gedanken, Kanten = Abhängigkeiten); ermöglicht Aggregation, Rückkopplungsschleifen und Verfeinerung über die linearen/baumartigen Beschränkungen von CoT/ToT hinaus.

#### ReAct (Reason + Act)
**ReAct: Synergizing Reasoning and Acting in Language Models** — Shunyu Yao, Jeffrey Zhao, Dian Yu, Nan Du, Izhak Shafran, Karthik Narasimhan, Yuan Cao (2022/2023), ICLR 2023, arXiv:2210.03629. Verschränkt Reasoning-Traces und aufgabenspezifische Aktionen; reduziert auf HotpotQA/Fever Halluzinationen. **Abgrenzungshinweis:** In der Kernform nutzt ReAct externe Quellen/APIs (z. B. Wikipedia) und liegt damit an der Grenze zwischen reinem Prompting und Tool-Nutzung – für Teil 2 (Tools/RAG) mitrelevant, als Prompting-Paradigma aber hier zentral.

#### Dekompositionsbasierte Verfahren
**Least-to-Most Prompting Enables Complex Reasoning in Large Language Models** — Denny Zhou, Nathanael Schärli, Le Hou, Jason Wei et al. (2022/2023), ICLR 2023, arXiv:2205.10625. Zwei-Stufen-Strategie: Zerlegung eines komplexen Problems in einfachere Teilprobleme und deren sequenzielle Lösung; verbessert die Easy-to-Hard-Generalisierung (z. B. SCAN).

**Decomposed Prompting: A Modular Approach for Solving Complex Tasks** — Tushar Khot et al. (2022), arXiv:2210.02406. Zerlegt Aufgaben in Teilprobleme, die von einer Bibliothek spezialisierter Prompt-basierter Handler bearbeitet werden (auch rekursiv).

#### Self-Refine / Selbstkritik / Reflexion
**Self-Refine: Iterative Refinement with Self-Feedback** — Aman Madaan, Niket Tandon, Prakhar Gupta et al. (2023), NeurIPS 2023, arXiv:2303.17651. Dasselbe Modell **generiert, kritisiert und verbessert** iterativ seine Ausgabe ohne zusätzliches Training oder Fine-Tuning; laut Autoren lässt sich selbst GPT-4 zur Testzeit weiter verbessern.

#### Persona / Rollen-Prompting
**When "A Helpful Assistant" Is Not Really Helpful: Personas in System Prompts Do Not Improve Performances of Large Language Models** — Mingqian Zheng et al. (2023/2024), arXiv:2311.10054. Wichtige empirische Korrektur: Analyse von 162 Personas über vier Open-Source-LLM-Familien und 2.410 Faktenfragen zeigt, dass Personas in System-Prompts die Leistung **nicht** zuverlässig verbessern. Bemerkenswert: Die ursprüngliche (positive) Abstract-Aussage von 2023 wurde in der Revision von Oktober 2024 explizit zurückgenommen. Keine Persona-Auswahlstrategie übertraf zufällige Auswahl.

#### Meta-Prompting
**Meta-Prompting: Enhancing Language Models with Task-Agnostic Scaffolding** — Mirac Suzgun, Adam Tauman Kalai (2024), arXiv:2401.12954. Ein LLM als „Dirigent", das Teilaufgaben an spezialisierte „Experten"-Instanzen desselben Modells delegiert und deren Ausgaben integriert. Mit GPT-4 und Python-Interpreter übertraf Meta-Prompting Standard-Prompting im Mittel um 17,1 %, Expert(dynamic)-Prompting um 17,3 % und Multipersona-Prompting um 15,2 % (Game of 24, Checkmate-in-One, Python Programming Puzzles).

#### Automatische Prompt-Optimierung (Hard Prompts)
**Large Language Models Are Human-Level Prompt Engineers (APE)** — Yongchao Zhou, Andrei Ioan Muresanu, Ziwen Han et al. (2022/2023), ICLR 2023, arXiv:2211.01910. Behandelt Instruktionen als „Programme"; ein LLM generiert Kandidaten, die per Score-Funktion (Zero-Shot-Performance) ausgewählt werden. Übertraf menschliche Prompts auf einem Großteil von 24 NLP-Aufgaben.

**Large Language Models as Optimizers (OPRO)** — Chengrun Yang, Xuezhi Wang, Yifeng Lu, Hanxiao Liu, Quoc V. Le, Denny Zhou, Xinyun Chen (2023), ICLR 2024, arXiv:2309.03409. LLM als Optimierer, der in natürlicher Sprache beschriebene Aufgaben löst, indem er iterativ neue Lösungen aus zuvor generierten, bewerteten Kandidaten erzeugt. Verbatim: „the best prompts optimized by OPRO outperform human-designed prompts by up to 8% on GSM8K, and by up to 50% on Big-Bench Hard tasks."

**Promptbreeder: Self-Referential Self-Improvement Via Prompt Evolution** — Chrisantha Fernando, Dylan Banarse, Henryk Michalewski, Simon Osindero, Tim Rocktäschel (2023), ICML 2024, arXiv:2309.16797. Evolutionäre, **selbstreferenzielle** Prompt-Optimierung: mutiert eine Population von Task-Prompts, wobei die Mutations-Prompts selbst mitentwickelt werden. Übertrifft CoT und Plan-and-Solve auf Arithmetik-/Commonsense-Benchmarks. (Verwandt: **EvoPrompt**, Guo et al. 2023, arXiv:2309.08532, ICLR 2024.)

**DSPy: Compiling Declarative Language Model Calls into Self-Improving Pipelines** — Omar Khattab, Arnav Singhvi, Paridhi Maheshwari et al. (2023), arXiv:2310.03714. Programmiermodell, das LM-Pipelines als deklarative Module (mit typisierten Signaturen) abstrahiert und per Compiler gegen eine Metrik optimiert („Programmieren statt Prompten"). Vereint Prompting, Demonstrations-Generierung und optional Fine-Tuning – für Teil 2/3 des Projekts brückenbildend.

#### Soft Prompts (zur Abgrenzung)
**The Power of Scale for Parameter-Efficient Prompt Tuning** — Brian Lester, Rami Al-Rfou, Noah Constant (2021), EMNLP 2021, arXiv:2104.08691. Führt **Soft Prompts** (kontinuierliche, per Backpropagation gelernte Vektoren) ein. Verbatim: „Unlike the discrete text prompts used by GPT-3, soft prompts are learned through backpropagation … as models exceed billions of parameters, our method 'closes the gap' and matches the strong performance of model tuning". **Wichtiger Abgrenzungshinweis:** Prompt Tuning nutzt Gradientenupdates und ist damit im engeren Sinne **kein rein prompt-basiertes Verfahren** (gehört systematisch näher an Teil 3, Fine-Tuning) – für die Hard-vs-Soft-Prompt-Unterscheidung jedoch unverzichtbar.

#### Prompt-Kompression
**LLMLingua: Compressing Prompts for Accelerated Inference of Large Language Models** — Huiqiang Jiang, Qianhui Wu, Chin-Yew Lin, Yuqing Yang, Lili Qiu (2023), EMNLP 2023, arXiv:2310.05736 (ACL Anthology DOI 10.18653/v1/2023.emnlp-main.825). Coarse-to-fine-Kompression mit Budget-Controller und token-weiser iterativer Kompression; laut Abstract „up to 20x compression with little performance loss" (GSM8K, BBH, ShareGPT, Arxiv-March23; unter 2 Punkte EM-Verlust auf GSM8K). Erweiterungen: **LongLLMLingua** (arXiv:2310.06839, ACL 2024) und **LLMLingua-2** (Pan et al., 2024, taskagnostisch via Token-Klassifikation).

### 3. Empirische Vergleichsstudien
- **Sclar et al. (2023), *Quantifying Language Models' Sensitivity to Spurious Features in Prompt Design* (FormatSpread)**, arXiv:2310.11324, ICLR 2024. Verbatim: „several widely used open-source LLMs are extremely sensitive to subtle changes in prompt formatting in few-shot settings, with performance differences of up to 76 accuracy points when evaluated using LLaMA-2-13B"; auch GPT-3.5-Turbo zeigt Spannen bis 56 Punkte (Median 6,4) über 320 Formate und 53 Aufgaben. Empfehlung der Autoren: Leistung als **Intervall** über plausible Formate berichten, nicht als Einzelwert.
- **Meincke, Mollick, Mollick & Shapiro (2025), *The Decreasing Value of Chain of Thought in Prompting* (Prompting Science Report 2)**, arXiv:2506.07142 (SSRN 5285532). Kernbefund verbatim: „For dedicated reasoning models, the added benefits of explicit CoT prompting appear negligible" – bei Reasoning-Modellen nur marginale Gewinne trotz 20–80 % höherer Antwortzeit; bei Nicht-Reasoning-Modellen kleine Durchschnittsgewinne, aber erhöhte Varianz.
- **The Prompt Report** (Schulhoff et al., 2024) selbst enthält eine große Meta-Analyse: Few-Shot und CoT übertreffen konsistent Zero-Shot, doch Reihenfolge/Diversität der Exemplare und Instruktionen beeinflussen die Ergebnisse stark.

### 4. Aktuelle Entwicklungen (2024–2026)
- **Verschiebung zur automatischen Prompt-Optimierung**: OPRO (ICLR 2024), Promptbreeder/EvoPrompt (ICML/ICLR 2024), DSPy als Programmier-Paradigma. Trend: „Prompts als Code" und algorithmische Suche statt manuellem Handwerk.
- **Kritische Neubewertung etablierter Techniken**: sinkender CoT-Nutzen bei Reasoning-Modellen (Meincke et al., 2025); Widerlegung genereller Persona-Vorteile (Zheng et al., 2024).
- **Effizienz-Fokus**: Prompt-Kompression (LLMLingua-Familie) für Kostensenkung und lange Kontexte.
- **Robustheits-/Sensitivitätsforschung** als eigenes Teilgebiet (POSIX, FormatSpread, ProSA/Prompt-SensiScore; jüngere Benchmarks wie Brittlebench, arXiv:2603.13285).

### 5. Limitationen, Fehlermodi und Kritik
- **Brüchigkeit/Sensitivität**: Sclar et al. (2023, arXiv:2310.11324); POSIX-Prompt-Sensitivity-Index (Chatterjee et al., 2024). Selbst semantisch äquivalente Umformulierungen, Whitespace oder Optionsreihenfolge verändern Vorhersagen erheblich.
- **Prompt Injection (Sicherheit)**: Perez & Ribeiro (2022) prägten den „ignore attack" (Goal Hijacking und Prompt Leaking); Greshake et al. (2023) beschrieben erstmals **indirekte** Prompt Injection über vergiftete externe Daten. Gelistet als Top-10-Bedrohung (OWASP für LLM-Anwendungen).
- **Begrenzte/kontextabhängige Wirksamkeit**: Persona-Prompting (Zheng et al.) und explizites CoT bei Reasoning-Modellen (Meincke et al.) liefern oft keinen verlässlichen Mehrwert.
- **Methodische Kritik am Benchmarking**: Modellvergleiche mit einem einzigen, willkürlich gewählten Prompt-Format sind laut Sclar et al. von fragwürdiger Validität.

### 6. Best-Practice-Leitfäden der Industrie (ergänzende Praxisressourcen)
- **OpenAI – „Prompt engineering" / „Best practices for prompt engineering with the OpenAI API"** (developers.openai.com bzw. Help Center). Sechs Kernstrategien: klare Instruktionen; Referenztext bereitstellen; komplexe Aufgaben in Teilaufgaben zerlegen; dem Modell „Zeit zum Denken" geben (Schritt-für-Schritt); externe Tools; systematisches Testen. Empfiehlt temperature=0 für faktische/deterministische Aufgaben.
- **Anthropic – „Prompt engineering overview" (Claude-Dokumentation)** (platform.claude.com/docs bzw. docs.anthropic.com; interaktives Tutorial auf GitHub). Betont Explizitheit, **XML-Tags zur Strukturierung**, Multishot-Beispiele, Chain-of-Thought sowie „define success criteria + build evals first"; rahmt Prompt Engineering als ressourcen- und kosteneffiziente Alternative zum Fine-Tuning.
- **Google – „Prompt Engineering" Whitepaper** von Lee Boonstra (September 2024, für Kaggles Gen-AI-Intensive). Behandelt Zero-/One-/Few-Shot, System-/Role-/Contextual-Prompting, Step-Back-Prompting, CoT, Self-Consistency, ToT, ReAct und automatisches Prompt Engineering; betont Konfiguration (Output-Länge, Temperature, Top-K, Top-P) und den iterativen Charakter.
- Ergänzend praxisnah: der offene **Prompt Engineering Guide** (promptingguide.ai) und **Learn Prompting** (learnprompting.org).

## Recommendations
1. **Gerüst zuerst**: Beginnen Sie mit den beiden Surveys (Schulhoff et al. 2024, arXiv:2406.06608; Sahoo et al. 2024, arXiv:2402.07927) und übernehmen Sie deren Taxonomie als Gliederungsraster.
2. **Chronologisch-thematisch ordnen**: ICL (Brown 2020) → CoT-Familie (Wei 2022 → Kojima 2022 → Wang 2022 → Auto-CoT) → strukturierte Frameworks (ToT, GoT) → iterative/agentische Verfahren (Self-Refine, ReAct) → automatische Optimierung (APE, OPRO, PromptBreeder, DSPy) → Kompression (LLMLingua).
3. **Sauber abgrenzen** (kritisch für die Dreiteilung des Gesamtprojekts): reines Prompting/Hard Prompts vs. Soft Prompts/Prompt Tuning (Gewichtsupdates → näher an Teil 3) vs. tool-/retrieval-nutzende Verfahren wie ReAct und DSPy-Retrieval-Module (→ Teil 2). Kennzeichnen Sie Grenzfälle explizit.
4. **Eigenes Limitationskapitel**: Brüchigkeit (Sclar 2023; POSIX), Prompt Injection (Perez & Ribeiro 2022; Greshake 2023) und die kritischen Revisionen (Persona, CoT bei Reasoning-Modellen) verdienen einen eigenen Abschnitt, um Ausgewogenheit zu wahren.
5. **Methodenhinweis übernehmen**: Zitieren Sie bei jedem Wirksamkeitsclaim das verwendete Modell und – wo möglich – ein Leistungs*intervall* über Formate (Empfehlung von Sclar et al.), statt Einzelwerte.
6. **Priorisierung der Quellen**: Peer-reviewte/hochzitierte Arbeiten (NeurIPS, ICLR, ICML, EMNLP, AAAI) als Primärbelege; Industrie-Whitepapers nur als praktische Ergänzung kennzeichnen.

**Schwellen, die Empfehlungen ändern würden**: Falls Ihr Zielmodell ein dediziertes Reasoning-Modell (o1-/R1-Klasse) ist, verschiebt sich die Priorität weg von explizitem CoT/Self-Consistency (marginaler Nutzen laut Meincke et al. 2025) hin zu Aufgabenstrukturierung, Dekomposition und automatischer Optimierung. Falls externe Datenquellen zulässig werden, wandern ReAct/DSPy in den Fokus von Teil 2.

## Caveats
- **Überschneidungen mit Teil 2/3**: ReAct (Tools), DSPy (Pipelines/Optimierung) und Prompt Tuning/Soft Prompts (Gewichtsupdates) berühren formal die anderen Projektteile; hier nur unter dem Prompting-Aspekt behandelt.
- **arXiv-IDs prüfen**: Die IDs wurden aus mehreren Sekundärnennungen zusammengetragen. Besonders zu verifizieren vor finaler Zitation: Graph-of-Thoughts (arXiv:2308.09687), Auto-CoT (arXiv:2210.03493), Decomposed Prompting (arXiv:2210.02406) und EvoPrompt (arXiv:2309.08532), da diese teils nur über Referenzlisten belegt sind.
- **Zählungen sind quellenabhängig**: „58 Techniken" (Schulhoff) bzw. „über 40 Techniken" (Sahoo) hängen von der jeweiligen Zählkonvention ab; die genaue Zahl bei Sahoo et al. im Volltext bestätigen.
- **Versionsstände**: Mehrere Arbeiten (z. B. Zheng et al. zu Personas; Dong et al. ICL-Survey) wurden substanziell überarbeitet – zitieren Sie die konkrete Version und beachten Sie, dass sich Kernaussagen zwischen Versionen geändert haben.
- **Industrie-Leitfäden** sind nicht peer-reviewt und können sich häufig ändern; als Sekundär-/Praxisquellen kennzeichnen.